package part4.entwurfsmuster.behavioral.interpreter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Stack;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class InfixToPostfixConverter {

    static Map<String, Integer> precedence = Map.of("^", 4,
            "*", 3, "/", 3, "+", 2, "-", 2, "(", 1, ")", 1);

    public static String infixToPostfix(String infixExpr) {
        final String OPERATORS = "^*/+-()";

        Stack<String> opStack = new Stack<>();
        List<String> postfixList = new ArrayList<>();

        String[] tokenList = infixExpr.split(" ");

        for (String token : tokenList) {
            if (token.equals("(")) {
                opStack.push(token);
            } else if (token.equals(")")) {
                // pop everything down to the matching open paren
                String topToken = opStack.pop();
                while (!topToken.equals("(")) {
                    postfixList.add(topToken);
                    topToken = opStack.pop();
                }
            } else if (OPERATORS.contains(token)) {
                // pop higher-precedence operations
                while (!opStack.isEmpty() &&
                        (precedence.get(opStack.peek())
                                >= precedence.get(token))) {
                    postfixList.add(opStack.pop());
                }
                // then push this operator
                opStack.push(token);
            } else {
                // Name oder Zahl
                postfixList.add(token);
            }
        }

        // If any operators remain, add them to the postfix expression
        while (!opStack.isEmpty()) {
            postfixList.add(opStack.pop());
        }

        String result = "";
        for (String s : postfixList) {
            result = result + s + " ";
        }
        return result;

    }

    public static void main(String[] args) {

        String expr = "A * B + C * 11";
        System.out.println(expr + " --> " + infixToPostfix(expr));

        expr = "( A + B ) * C - ( D - E ) * ( F + G )";
        System.out.println(expr + " --> " + infixToPostfix(expr));
    }
}

package part4.entwurfsmuster.behavioral.interpreter;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public abstract class BinaryExpression implements Expression
{
    final Expression left;
    final Expression right;

    public BinaryExpression(final Expression left, final Expression right)
    {
        this.left = left;
        this.right = right;
    }

    @Override
    public String toString()
    {
        return left.toString() + " " + getOperatorSymbol() + " " + right.toString();
    }

    protected abstract String getOperatorSymbol();
}

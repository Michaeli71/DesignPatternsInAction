package part4.entwurfsmuster.behavioral.memento;

import java.time.LocalDate;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class BusinessObject {
    private String info;
    private LocalDate date;
    private int value;

    public Memento saveStateToMemento() {
        return new Memento(info, date, value);
    }

    public void restoreStateFromMemento(Memento memento) {
        info = memento.getInfo();
        date = memento.getDate();
        value = memento.getValue();
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Originator [info=" + info + ", date=" + date + ", value=" + value + "]";
    }
}

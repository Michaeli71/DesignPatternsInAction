package part4.entwurfsmuster.behavioral.observer;

import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ObserverExample
{
    public static void main(String[] args)
    {
        DataModel model = new DataModel();
        View view = new View();
        
        model.setInfo("Info");        
        model.registerDataChangeListener(view);
        
        // nun wird es reportiert
        model.setInfo("Info 2");
        model.setValue(1234);        

        model.selectIndex(27);
        
        model.registerSelectionChangeListener(view);
        model.selectIndex(42);
        model.selectIndex(43);
        model.selectIndex(44);
        model.deregisterSelectionChangeListener(view);
        model.selectIndex(7271);
        
        model.setNames(List.of("Tim", "Tom", "Peter"));
    }
}

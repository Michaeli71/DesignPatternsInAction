package part4.entwurfsmuster.behavioral.observer;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
// Null Object Muster
public class NoOpListener implements DataChangeListener, SelectionChangeListener
{
    @Override
    public void dataChanged(Object data)
    {
    }

    @Override
    public void selectionChanged(Integer selection)
    {
    }
}

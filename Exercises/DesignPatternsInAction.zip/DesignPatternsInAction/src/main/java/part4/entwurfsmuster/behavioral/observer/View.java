package part4.entwurfsmuster.behavioral.observer;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class View implements DataChangeListener, SelectionChangeListener
{
    @Override
    public void dataChanged(Object data)
    {
        System.out.println("Data changed: "  + data );        
    }

    @Override
    public void selectionChanged(Integer selection)
    {
        System.out.println("Selection changed: " + selection);        
    }
}

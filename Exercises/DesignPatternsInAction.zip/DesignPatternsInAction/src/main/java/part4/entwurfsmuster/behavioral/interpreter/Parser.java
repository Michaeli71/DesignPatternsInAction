package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Stack;
import java.util.regex.Pattern;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
class Parser
{
    static public Expression parseExpression(final String expression)
    {       
        Pattern numberPattern = Pattern.compile("[+-]?\\d+");

        Stack<Expression> expressionStack = new Stack<>();

        for (String token : expression.split(" "))
        {
            if (ExpressionUtils.isBinaryOperator(token))
            {
                Expression subExpression = ExpressionUtils.getBinaryOperator(token, expressionStack.pop(),
                                                                             expressionStack.pop());
                expressionStack.push(subExpression);
            }

            /* Erweiterung 2 */
            // 
            else if (token.equals("sqr") || token.equals("**"))
            {
                Expression subExpression = new SqrFunction(expressionStack.pop());
                expressionStack.push(subExpression);
            }
            else if (token.equals("vit") || token.equals("10times"))
            {
                Expression subExpression = new VitFunction(expressionStack.pop());
                expressionStack.push(subExpression);

            } 
            // Nummer oder Variable   
            else if (numberPattern.matcher(token).matches())
            {
                expressionStack.push(new SimpleNumber(Integer.parseInt(token.trim())));
            }
            else
                expressionStack.push(new Variable(token));
        }

        return expressionStack.pop();
    }
}
package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
/* Erweiterung 2 */
class SqrFunction implements Expression
{
    private final Expression operand;

    public SqrFunction(final Expression operand)
    {
        this.operand = operand;
    }

    @Override
    public int interpret(final Map<String, Integer> variables)
    {
        int tmp = operand.interpret(variables);
        return tmp * tmp;
    }
}
package part4.entwurfsmuster.behavioral.strategy;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public interface FilterStrategy {
    public abstract boolean acceptValue(final int value);
}
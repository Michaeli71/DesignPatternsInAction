package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
/* Erweiterung 3 */
/* TenTimes */
class TenTimesFunction implements Expression {
    private final Expression operand;

    public TenTimesFunction(final Expression operand) {
        this.operand = operand;
    }

    @Override
    public int interpret(final Map<String, Integer> variables) {
        int tmp = operand.interpret(variables);
        return tmp * 10;
    }
}
package part4.entwurfsmuster.behavioral.memento;

import java.time.LocalDate;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class MementoPatternDemo {
    public static void main(String[] args) {
        final CareTaker careTaker = new CareTaker();

        final BusinessObject originator = new BusinessObject("Initial",
                LocalDate.now(), 42);
        System.out.println(originator);

        careTaker.saveState(originator.createMementoFromState());

        originator.setValue(43);
        System.out.println("After Value changed 43:" + originator);
        careTaker.saveState(originator.createMementoFromState());

        originator.setInfo("Setting to 44");
        originator.setValue(44);
        System.out.println("After Value changed 44:" + originator);
        careTaker.saveState(originator.createMementoFromState());

        originator.setInfo("Setting to 55");
        originator.setValue(55);
        originator.setDate(LocalDate.now());
        System.out.println("After Value changed 55:" + originator);
        careTaker.saveState(originator.createMementoFromState());

        // changes, aber nicht persitiert
        originator.setInfo("Some Changes");
        System.out.println(originator);
        originator.setInfo("But not stored");
        System.out.println(originator);
        originator.setInfo("But discarded");
        System.out.println(originator);

        System.out.println("Restoring last state befor changes");
        originator.restoreStateFromMemento(careTaker.restoreLast());
        System.out.println(originator);

        originator.restoreStateFromMemento(careTaker.restore(3));
        System.out.println(originator);

        originator.restoreStateFromMemento(careTaker.restore(2));
        System.out.println(originator);

        originator.restoreStateFromMemento(careTaker.restore(1));
        System.out.println(originator);

        originator.restoreStateFromMemento(careTaker.restore(0));
        System.out.println(originator);
    }
}
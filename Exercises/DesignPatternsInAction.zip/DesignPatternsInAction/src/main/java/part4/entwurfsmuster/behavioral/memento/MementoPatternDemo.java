package part4.entwurfsmuster.behavioral.memento;

import java.time.LocalDate;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class MementoPatternDemo {
    public static void main(String[] args) {
        final CareTaker careTaker = new CareTaker();

        final BusinessObject originator = new BusinessObject();
        originator.setInfo("Initial");
        originator.setDate(LocalDate.now());
        originator.setValue(42);
        System.out.println(originator);

        careTaker.saveState(originator.saveStateToMemento());
        originator.setValue(43);
        careTaker.saveState(originator.saveStateToMemento());
        originator.setValue(44);
        originator.setInfo("Setting to 44");
        careTaker.saveState(originator.saveStateToMemento());
        originator.setInfo("Some Changes");
        System.out.println(originator);

        originator.restoreStateFromMemento(careTaker.restoreLast());
        System.out.println(originator);

        originator.restoreStateFromMemento(careTaker.restore(1));
        System.out.println(originator);

        originator.restoreStateFromMemento(careTaker.restore(0));
        System.out.println(originator);
    }
}
package part4.entwurfsmuster.behavioral.strategy;

import part4.entwurfsmuster.behavioral.strategy.FilterStrategies.ClosedInterval;
import part4.entwurfsmuster.behavioral.strategy.FilterStrategies.OpenInterval;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Beispielprogramm zur Filterung mithilfe des Strategie-Musters
 * <br>
 * Die Klasse <code>StrategyFilterExample</code> zeigt eine Filterung
 * von einer Liste von Integer-Werten und zwei Filter-Kriterien
 * (offenes und geschlossenes Intervall).
 * Als Erweiterung zum einf�hrenden Beispiel  <code>StrategyFilterBaseExample</code>
 * wird die Filterung hier nicht in der Methode <code>filterAll()</code> ausprogrammiert,
 * sondern stattdessen an eine <code>FilterStrategy</code> delegiert. Dieses Interface
 * wird hier von den beiden Realisierungen <code>ClosedInterval</code> und <code>OpenInterval</code>
 * erf�llt.
 *
 * @author Michael Inden
 * <p>
 * Copyright 2011 by Michael Inden
 */
public final class StrategyFilterExample {
    public static List<Integer> filterAll(final List<Integer> inputs,
                                          final FilterStrategy filterStrategy) {
        final List<Integer> result = new ArrayList<>();
        for (final Integer value : inputs) {
            if (filterStrategy.acceptValue(value))
                result.add(value);
        }

        return result;
    }

    public static void main(final String[] args) {
        final List<Integer> inputs = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);

        System.out.println("Filtering values for Intervall 2-7");
        final FilterStrategy closedInterval = new ClosedInterval(2, 7);
        System.out.println("Using " + closedInterval + " " + filterAll(inputs, closedInterval));

        final FilterStrategy openInterval = new OpenInterval(2, 7);
        System.out.println("Using " + openInterval + " " + filterAll(inputs, openInterval));

        final FilterStrategy isOdd = new FilterStrategies.IsOdd();
        System.out.println("Using " + isOdd + " " + filterAll(inputs, isOdd));

        // Seit Java 8 ...
        final FilterStrategy isEven = n -> n % 2 == 0;
        System.out.println("Using " + isEven + " " + filterAll(inputs, isEven));

        final FilterStrategy isInRange = isInRange(3, 7);
        System.out.println("Using " + isInRange + " " + filterAll(inputs, isInRange));
    }

    public static FilterStrategy isInRange(int lower, int upper) {
        return n -> n >= lower && n <= upper;
    }


}

package part4.entwurfsmuster.behavioral.memento;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class CareTaker {
    private final List<Memento> storedStates = new ArrayList<>();

    void saveState(Memento currentSate) {
        storedStates.add(currentSate);
    }

    Memento restoreLast() {
        return restore(storedStates.size() - 1);
    }

    Memento restore(int index) {
        // Diskussion: sollen Stati gelöscht werden oder beibehalten
        // return storedStates.remove(index);
        return storedStates.get(index);
    }
}

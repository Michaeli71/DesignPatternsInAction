package part4.entwurfsmuster.behavioral.interpreter;

import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class ExpressionUtils {
    static final List<String> OPERATORS = List.of("+", "-", "*", "/", "^");

    public static boolean isBinaryOperator(String input) {
        return OPERATORS.contains(input);
    }

    public static Expression getBinaryOperator(String input, Expression left, Expression right) {
        switch (input) {
            case "+":
                return new Plus(left, right);
            case "-":
                return new Minus(left, right);
            case "*":
                return new Mult(left, right);
            case "/":
                return new Div(left, right);
            case "^":
                return new Pow(left, right);
        }
        throw new IllegalStateException("Unsupported operand");
    }
}
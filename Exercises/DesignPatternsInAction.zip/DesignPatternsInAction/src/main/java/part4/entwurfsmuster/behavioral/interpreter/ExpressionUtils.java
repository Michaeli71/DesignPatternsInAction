package part4.entwurfsmuster.behavioral.interpreter;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ExpressionUtils
{
    public static boolean isBinaryOperator(String input)
    {
        if (input.equals("+") || input.equals("-") || input.equals("*"))
            return true;
        else
            return false;
    }

    public static Expression getBinaryOperator(String input, Expression left, Expression right)
    {
        switch (input)
        {
            case "+":
                return new Plus(left, right);
            case "-":
                return new Minus(left, right);
            case "*":
                return new Mult(left, right);
        }
        throw new IllegalStateException("Unsupported operand");
    }
}
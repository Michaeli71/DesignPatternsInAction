package part4.entwurfsmuster.behavioral.nullobject;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class NullObjectExample {
    interface ISimplePerson {
        String getName();

        boolean isAdult();
    }

    static class SimplePerson {
        String name;

        int age;

        static {
            // heavy init
            //DB.getInfos()
        }

        String getName() {
            return name;
        }

        boolean isAdult() {
            //
            return true;
        }
    }

    static class NullSimplePerson implements ISimplePerson {
        @Override
        public String getName() {
            return "n/a";
        }

        @Override
        public boolean isAdult() {
            return false;
        }
    }

    public static void main(String[] args) {
        // Null Object seit Java 8 => Optional
        ISimplePerson person = findPerson();
        if (person != null)
            System.out.println("Found: " + person.getName());
        else
            System.out.println("Found: " + "n/a");

        // Preferable seit Java 8
        Optional<SimplePerson> optPerson = findPersonImproved();

        // Null Object good
        List<ISimplePerson> names = findPersons();
        System.out.println("Found: " + names.size() + " items");
    }

    private static List<ISimplePerson> findPersons() {
        // Suche nicht erfolgreich
        return Collections.emptyList();
    }

    static ISimplePerson findPerson() {
        // heavy logic
        //return null;

        return new NullSimplePerson();
    }

    static Optional<SimplePerson> findPersonImproved() {
        // heavy logic
        //return null;

        return Optional.empty();
    }
}

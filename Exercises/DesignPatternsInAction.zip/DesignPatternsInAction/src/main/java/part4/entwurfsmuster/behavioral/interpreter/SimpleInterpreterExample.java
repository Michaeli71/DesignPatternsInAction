package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;
import java.util.Stack;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
// Hier ohne Variablen
public class SimpleInterpreterExample {
    public static void main(String[] args) {
        String tokenString = "7 ** 2 +";
        evaluate(tokenString);

        String tokenString1 = "7 squared 2 +";
        evaluate(tokenString1);

        String tokenString1b = "3 4 + 5 *";
        evaluate(tokenString1b);

        String tokenString2 = "7 3 - 2 1 + *";
        evaluate(tokenString2);

        String tokenString3 = "7 3 + 2 3 ^ * 38 -";
        evaluate(tokenString3);
    }

    private static void evaluate(String tokenString) {
        Stack<Expression> stack = new Stack<>();
        String[] tokenArray = tokenString.split(" ");

        for (String token : tokenArray) {
            if (ExpressionUtils.isBinaryOperator(token)) {
                // ACHTUNG: Reihenfolge der Argumente!!!
                Expression second = stack.pop();
                Expression first = stack.pop();
                Expression operator = ExpressionUtils.getBinaryOperator(token, first, second);

                int result = operator.interpret(Map.of());
                stack.push(new SimpleNumber(result));

            } else if (token.equals("squared") || token.equals("**")) {
                Expression operator = new SquaredFunction(stack.pop());

                int result = operator.interpret(Map.of());
                stack.push(new SimpleNumber(result));
            } else {
                Expression expr = new SimpleNumber(Integer.parseInt(token));
                stack.push(expr);
            }
        }

        System.out.println(tokenString + " = " + stack.pop().interpret(Map.of()));
    }
}
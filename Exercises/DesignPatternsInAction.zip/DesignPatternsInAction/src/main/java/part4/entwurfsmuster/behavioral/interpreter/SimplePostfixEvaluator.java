package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Stack;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class SimplePostfixEvaluator {

    public static Integer postfixEval(String postfixExpr) {

        Stack<Integer> operandStack = new Stack<Integer>();

        String[] tokenList = postfixExpr.split(" ");

        for (String token : tokenList) {
            if (isOperator(token)) {
                Integer operand2 = operandStack.pop();
                Integer operand1 = operandStack.pop();
                Integer result = evaluate(token, operand1, operand2);
                operandStack.push(result);
            } else {
                operandStack.push(Integer.parseInt(token));
            }
        }
        return operandStack.pop();
    }

    private static boolean isOperator(String token) {
        return "*/+-".contains(token);
    }

    public static Integer evaluate(String operator, Integer operand1, Integer operand2) {
        switch (operator) {
            case "*":
                return operand1 * operand2;
            case "/":
                return operand1 / operand2;
            case "+":
                return operand1 + operand2;
            case "-":
                return operand1 - operand2;
            default:
                throw new IllegalArgumentException("Invalid operator: " + operator);
        }
    }

    public static void main(String[] args) {
        System.out.println(postfixEval("5 1 + 4 3 + *"));

        System.out.println(postfixEval("55 22 + 7 3 + * 7 +"));
    }

    static void dominanceExampleWithConstant(final Object obj) {
        switch (obj.toString()) {
            case String str when str.length() > 5 -> System.out.println(str);
            case "Sophie" -> System.out.println("My lovely daughter");
            default -> System.out.println("FALLBACK");
        }
    }
}

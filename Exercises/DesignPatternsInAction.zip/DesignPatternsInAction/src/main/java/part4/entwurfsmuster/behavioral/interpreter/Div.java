package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
/* Erweiterung 1 */
class Div extends BinaryExpression {

    public Div(Expression left, Expression right) {
        super(left, right);
    }

    @Override
    public int interpret(final Map<String, Integer> variables) {
        return left.interpret(variables) / right.interpret(variables);
    }

    @Override
    protected String getOperatorSymbol() {
        return "/";
    }
}
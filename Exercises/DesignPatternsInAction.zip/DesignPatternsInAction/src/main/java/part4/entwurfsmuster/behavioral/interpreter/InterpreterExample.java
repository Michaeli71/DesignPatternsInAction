package part4.entwurfsmuster.behavioral.interpreter;

import java.util.HashMap;
import java.util.Map;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class InterpreterExample {
    public static void main(final String[] arguments) {
        // UPN
        final Expression tree1 = Parser.parseExpression("7 5 +");

        System.out.println(tree1.interpret(Map.of()));

        final Expression tree2 = Parser.parseExpression("55 22 + 7 3 + * 7 +");

        System.out.println(tree2.interpret(Map.of()));

        // Erweiterung 1
        final Expression tree3 = Parser.parseExpression("7 5 *");

        System.out.println(tree3.interpret(Map.of()));

        // Erweiterung 2
        final Expression tree4 = Parser.parseExpression("4 ** 2 squared + 5 ^");

        System.out.println(tree4.interpret(Map.of()));

        // Erweiterung 3
        final Expression tree5 = Parser.parseExpression("7 x10 5 10times +");

        System.out.println(tree5.interpret(Map.of()));

        // ------------------------------------------------------------------

        final String expression = "price rabatt - bonus +";

        // KONTEXT
        final HashMap<String, Integer> variables = new HashMap<>();

        variables.put("price", 53);
        variables.put("rabatt", 42);
        variables.put("bonus", 10);

        final Expression tree = Parser.parseExpression(expression);

        System.out.println(tree.interpret(variables));

        // infixExpression = "A*(B-C)/D+E+F";
        final String expression2 = "A B C - * D / E + F +";
        var variables2 = Map.of("A", 8, "B", 4, "C", 2, "D", 5, "E", 11, "F", 3);
        final Expression treeB = Parser.parseExpression(expression2);

        System.out.println(treeB.interpret(variables2));
    }
}
package part4.entwurfsmuster.behavioral.interpreter;

import java.util.HashMap;
import java.util.Map;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class InterpreterExample
{
    public static void main(final String[] arguments)
    {
        // UPN
        final Expression tree2 = Parser.parseExpression("7 5 +");

        System.out.println(tree2.interpret(Map.of()));

        // Erweiterung 1
        final Expression tree3 = Parser.parseExpression("7 5 *");

        System.out.println(tree3.interpret(Map.of()));

        // Erweiterung 2
        final Expression tree4 = Parser.parseExpression("4 ** 2 sqr +");

        System.out.println(tree4.interpret(Map.of()));

        // Erweiterung 3
        final Expression tree5 = Parser.parseExpression("7 vit 5 10times +");

        System.out.println(tree5.interpret(Map.of()));

        // ------------------------------------------------------------------

        final String expression = "price rabatt bonus - + -2 +";

        // String myexpressionTextField = "sqr(x * 2) + vit(x * 10) + 7";

        // KONTEXT
        final HashMap<String, Integer> variables = new HashMap<>();

        variables.put("price", 5);
        variables.put("rabatt", 33);
        variables.put("bonus", 10);

        final Expression tree = Parser.parseExpression(expression);

        System.out.println(tree.interpret(variables));

    }
}
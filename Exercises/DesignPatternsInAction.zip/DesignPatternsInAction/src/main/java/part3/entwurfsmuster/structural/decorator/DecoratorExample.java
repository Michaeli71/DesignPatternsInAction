package part3.entwurfsmuster.structural.decorator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class DecoratorExample
{
    interface Executor
    {
        public void doSomething(String param);
    }
    
    static class MyExecutor implements Executor
    {
        @Override
        public void doSomething(String param)
        {
            System.out.println(param);
        }
    }
    
    static class ProtokollDecorator implements Executor
    {
        Executor original;
        List<String> auditLog = new ArrayList<>();
        
        ProtokollDecorator(Executor original)
        {
            this.original = original;
        }
        
        @Override
        public void doSomething(String param)
        {
            auditLog.add("doSoemthing called with " + param);
            System.err.println("Calling " + param);
            System.err.flush();
            original.doSomething(param);
            
           System.err.println("Ended " + param);
           System.err.flush();
        }
        
        List<String> getAuditLog()
        {
            return Collections.unmodifiableList(auditLog);
        }
    }
    
    
    static class DoublingDecorator implements Executor
    {
        Executor original;
        
        DoublingDecorator(Executor original)
        {
            this.original = original;
        }
        
        @Override
        public void doSomething(String param)
        {
            original.doSomething(param);
            original.doSomething(param);
        }
    }
    
    static class TripleDecorator implements Executor
    {
        Executor original;
        
        TripleDecorator(Executor original)
        {
            this.original = original;
        }
        
        @Override
        public void doSomething(String param)
        {
            original.doSomething(param);
            original.doSomething(param);
            original.doSomething(param);
        }
    }
    
    public static void main(String[] args)
    {
        // einzelner Dekorator
        Executor exec = new ProtokollDecorator(new MyExecutor());
        exec.doSomething("Test1");
        exec.doSomething("Test2");
        
        // Decorator in Kombination
        Executor exec1 = new ProtokollDecorator(new TripleDecorator(new MyExecutor()));
        exec1.doSomething("Test1");
        exec1.doSomething("Test2");

//        // Zugriff auf ProtokollDecorator oder oben direkt den konkreten Typ nutzen
//        ProtokollDecorator protokollDec = (ProtokollDecorator)exec1;
//        System.out.println(protokollDec.getAuditLog());
//        
//        System.out.println("------------------------------");
//        
//        // 2. Variante des "Zusammenstöpsel" / Kombinieren
//        // Andere Reiehnfolge bringt andere Ergebnisse
//        Executor exec2 = new DoublingDecorator(new ProtokollDecorator(new MyExecutor()));
//        exec2.doSomething("Test1");
//        exec2.doSomething("Test2");
    }
}

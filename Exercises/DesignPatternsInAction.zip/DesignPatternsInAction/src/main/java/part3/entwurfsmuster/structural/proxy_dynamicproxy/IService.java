package part3.entwurfsmuster.structural.proxy_dynamicproxy;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public interface IService 
{
	public void doSomething();
	public String calculateSomething(int value);
}
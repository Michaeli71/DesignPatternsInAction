package part3.entwurfsmuster.structural.proxy_dynamicproxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

/**
 * Beispielprogramm zum kombinierten Einsatz von zwei dynamischen Proxies
 *
 * @author Michael Inden
 * <p>
 * Copyright 2017 by Michael Inden
 */
public class DynamicProxyCombinationExample {
    public static void main(final String[] args) {
        final IService service = createService();
        service.calculateSomething(42);
        service.doSomething();
    }

    private static IService createService() {
        final IService origService = new Service();
        final InvocationHandler handler1 = new PerformanceMeasureInvocationHandler(origService);

        final Class<?>[] proxyInterfaces = {IService.class};
        final IService proxiedService = (IService) Proxy.newProxyInstance(Service.class.getClassLoader(),
                proxyInterfaces, handler1);

        final InvocationHandler handler2 = new LoggingInvocationHandler(proxiedService);
        return (IService) Proxy.newProxyInstance(Service.class.getClassLoader(), proxyInterfaces, handler2);
    }
}
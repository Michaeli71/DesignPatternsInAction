package part3.entwurfsmuster.structural.proxy_dynamicproxy;

/**
 * Beispielprogramm zur Definition eines statischen Proxys
 *
 * @author Michael Inden
 * <p>
 * Copyright 2017 by Michael Inden
 */
public class StaticProxyExample {
    public static void main(String[] args) {
        final IService service = createService();
        service.calculateSomething(42);
        service.doSomething();
    }

    private static IService createService() {
        final IService oriinal = new Service();
        return new ServicePerformanceProxy(oriinal);
    }
}
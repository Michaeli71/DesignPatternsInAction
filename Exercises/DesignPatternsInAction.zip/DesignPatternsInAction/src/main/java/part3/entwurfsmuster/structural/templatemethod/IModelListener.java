package part3.entwurfsmuster.structural.templatemethod;

import part2.entwurfsmuster.creational.prototype.AbstractGraphicsElement;

import java.util.List;

/**
 * Observer-Mechanismus, um �nderungen im Modell darzustellen
 *
 * @author Michael Inden
 * <p>
 * Copyright 2011 by Michael Inden
 */
public interface IModelListener {
    public void imageElementsChanged(final List<AbstractGraphicsElement> images);

    public void pdfElementsChanged(final List<AbstractGraphicsElement> pdfs);

    public void nameChanged(final String newName);
}
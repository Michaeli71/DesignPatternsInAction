package part3.entwurfsmuster.structural.adapter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.AbstractListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.ListModel;

/**
 * The classes/objects participating in adapter pattern:
 * <ul>
 * <li> Target - defines the domain-specific interface that Client uses.
 * <li> Adapter - adapts the interface Adaptee to the Target interface. 
 * <li> Adaptee - defines an existing interface that needs adapting. 
 * <li> Client - collaborates with objects conforming to the Target interface.
 */
// Client = main / JList
// Adapter = ListToAbstractListModelAdapter
// Adaptee = List
// Target = ListModel
/**
 * Demonstration vom Adapter-MMuster.
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
public class AdapterExample
{
    public static void main(String[] args)
    {
        final List<String> names = Arrays.asList("Mike", "Andy", "Tim", "Tom", "Marco", "Nils");
        var persons = List.of(new Person("Dennis", 27), new Person("Tom", 72), new Person("Jerry", 79));
        
        // List -> ListModel
        //final ListModel<String> requiredIF = new GenericListToAbstractListModelAdapter<String>(names);
        final ListModel<Person> requiredIF = new GenericListToAbstractListModelAdapter<>(persons);
        
        final JList<Person> namesList = new JList<>(requiredIF);

        final JFrame frame = new JFrame("AdapterDemo");
        frame.setContentPane(namesList);
        frame.setSize(500, 300);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    record Person(String name, int age) {}
    
    
    // Adapter extends or implements desired IF
    private static final class ListToAbstractListModelAdapter extends AbstractListModel<String>
    {
        private final List<String> content = new ArrayList<>();

        public ListToAbstractListModelAdapter(final List<String> content)
        {
            this.content.addAll(content);
        }

        @Override
        public int getSize()
        {
            return content.size();
        }

        @Override
        public String getElementAt(int index)
        {
            return content.get(index);
        }
    }
    
    private static final class GenericListToAbstractListModelAdapter<T> extends AbstractListModel<T>
    {
        private final List<T> content = new ArrayList<>();

        public GenericListToAbstractListModelAdapter(final List<T> content)
        {
            this.content.addAll(content);
        }

        @Override
        public int getSize()
        {
            return content.size();
        }

        @Override
        public T getElementAt(int index)
        {
            return content.get(index);
        }
    }
}

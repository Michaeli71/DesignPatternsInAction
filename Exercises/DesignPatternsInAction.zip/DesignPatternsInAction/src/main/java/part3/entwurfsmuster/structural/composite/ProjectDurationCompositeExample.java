package part3.entwurfsmuster.structural.composite;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public final class ProjectDurationCompositeExample
{
    public static void main(final String[] args)
    {
        final ProjectComponent reqeng = new Task("Requirements Engineering", 21);
        final ProjectComponent mockups = new Task("Mockup-Gernation", 7);

        final ProjectComponent prototyping = new Task("Prototyping", 20);
        final ProjectComponent reviews = new Task("Reviews", 3);
        
        final ProjectComponent design = new Task("Design", 10);
        final ProjectComponent impl = new Task("Implementation", 100);
        final ProjectComponent test = new Task("Test", 13);

        // Gruppen definieren
        final ProjectGroup preparation = new ProjectGroup("Preparation");
        preparation.add(reqeng);
        preparation.add(mockups);
        printCosts(preparation);
        
        final ProjectGroup prototypingAndReview = new ProjectGroup("PrototypingAndReview");
        prototypingAndReview.add(prototyping);
        prototypingAndReview.add(reviews);
        printCosts(prototypingAndReview);

        final ProjectGroup implementation = new ProjectGroup("Implementation");
        implementation.add(design);
        implementation.add(impl);
        implementation.add(test);
        printCosts(implementation);
        
        
        final ProjectGroup mainProject = new ProjectGroup("mainProject");
        mainProject.add(preparation);
        mainProject.add(prototypingAndReview);
        mainProject.add(implementation);
        printCosts(mainProject);

        final ProjectGroup mainProject2 = new ProjectGroup("mainProject2");
        mainProject2.add(implementation);
        printCosts(mainProject2);
        
        final ProjectGroup superProject = new ProjectGroup("superProject");
        superProject.add(mainProject);
        superProject.add(mainProject2);
        printCosts(superProject);
        
        
        // Spezielle Gruppen
        final ProjectGroup justcoding = new ProjectGroup("just coding");
        justcoding.add(prototyping);
        justcoding.add(impl);
        printCosts(justcoding);
        
        final ProjectGroup justtesting = new ProjectGroup("just testing");
        justtesting.add(reviews);
        justtesting.add(test);
        printCosts(justtesting);
    }

    private static void printCosts(final ProjectComponent projectComponent)
    {
        System.out.println("Cost of '" + projectComponent.getName() + "': " + 
                           projectComponent.getDuration());
    }
    
    // ...
    
    public static abstract class ProjectComponent
    {
        private final String name;

        public ProjectComponent(final String name)
        {
            this.name = name;
        }

        public abstract int getDuration();

        public String getName()
        {
            return name;
        }
    }

    public static class Task extends ProjectComponent
    {
        private final int duration;

        public Task(final String name, final int duration)
        {
            super(name);
            this.duration = duration;
        }

        @Override
        public int getDuration()
        {
            return duration;
        }
    }

    public static class ProjectGroup extends ProjectComponent
    {
        final List<ProjectComponent> subprojects = new ArrayList<>();

        public ProjectGroup(final String name)
        {
            super(name);
        }

        @Override
        public int getDuration()
        {
            int costs = 0;
            for (final ProjectComponent current : subprojects)
            {
                costs += current.getDuration();
            }

            return costs;
        }

        public void add(final ProjectComponent projectComponent)
        {
            subprojects.add(projectComponent);
        }
    }    
}

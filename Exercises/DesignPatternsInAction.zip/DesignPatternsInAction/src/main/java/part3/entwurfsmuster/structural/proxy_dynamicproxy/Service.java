package part3.entwurfsmuster.structural.proxy_dynamicproxy;

import java.util.concurrent.TimeUnit;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Service implements IService
{
    @Override
    public void doSomething()
    {
        System.out.println("doSomething");
    }

    @Override
    public String calculateSomething(final int value)
    {
        System.out.println("calculateSomething");
        try
        {
            TimeUnit.SECONDS.sleep(3);
        }
        catch (final InterruptedException e)
        {
            // can't happen here, no other thread to interrupt us
        }

        return "" + value;
    }
}
package zzz_bonus_refactoring_to_patterns.common;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class ProjectGroup {
    private final List<Object> projectsAndProjectGroups = new ArrayList<>();

    public ProjectGroup() {
    }

    public void addProject(Project project) {
        projectsAndProjectGroups.add(project);
    }

    public void removeProject(Project project) {
        projectsAndProjectGroups.remove(project);
    }

    public void addProjectGroup(ProjectGroup projectGroup) {
        projectsAndProjectGroups.add(projectGroup);
    }

    public void removeProjectGroup(ProjectGroup projectGroup) {
        projectsAndProjectGroups.remove(projectGroup);
    }

    public List<Object> getProjects() {
        return Collections.unmodifiableList(projectsAndProjectGroups);
    }
}

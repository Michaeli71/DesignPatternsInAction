package zzz_bonus_refactoring_to_patterns.common;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Project {
    private final int cost;

    public Project(int cost) {
        this.cost = cost;
    }

    public int getCost() {
        return cost;
    }
}

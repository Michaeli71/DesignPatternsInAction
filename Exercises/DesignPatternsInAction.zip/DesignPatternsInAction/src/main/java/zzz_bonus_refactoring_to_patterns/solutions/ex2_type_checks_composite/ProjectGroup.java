package zzz_bonus_refactoring_to_patterns.solutions.ex2_type_checks_composite;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class ProjectGroup implements ProjectComponent {
    private final List<ProjectComponent> projectsAndProjectGroups = new ArrayList<>();

    public ProjectGroup() {
    }

    public void add(ProjectComponent projectComponent) {
        projectsAndProjectGroups.add(projectComponent);
    }

    public void remove(ProjectComponent projectComponent) {
        projectsAndProjectGroups.remove(projectComponent);
    }

    public List<ProjectComponent> getProjectComponents() {
        return Collections.unmodifiableList(projectsAndProjectGroups);
    }

    @Override
    public double calculateCost()
    {
        double sum = 0.0d;
        for (ProjectComponent pojectComponent : getProjectComponents()) {
            sum += pojectComponent.calculateCost();
        }
        return sum;
    }
}

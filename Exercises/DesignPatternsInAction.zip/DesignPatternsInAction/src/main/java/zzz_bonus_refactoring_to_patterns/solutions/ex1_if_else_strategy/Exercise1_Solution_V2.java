package zzz_bonus_refactoring_to_patterns.solutions.ex1_if_else_strategy;

import zzz_bonus_refactoring_to_patterns.common.Order;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Exercise1_Solution_V2 {

    //
    interface PricingStrategy {
        double calculatePrice(Order order);
    }

    record StandardStrategy() implements PricingStrategy {
        public double calculatePrice(Order order)
        {
            return order.amount();
        }
    }

    record PremiumStrategy() implements PricingStrategy {
        public double calculatePrice(Order order)
        {
            return order.amount() * 0.9;
        }
    }

    record VIPStrategy() implements PricingStrategy {
        public double calculatePrice(Order order)
        {
            return order.amount() * 0.8;
        }
    }

    // Zwichenschritt 3: Inline
    static double calculatePrice(Order order) {
        Type rtype = Type.valueOf(order.type().toUpperCase());
        var pricingStrategy = rtype.getStrategy();

        return pricingStrategy.calculatePrice(order);
    }

    // Zwichenschritt 2: Methode als Komptibilitätslayer
    /*
    static PricingStrategy strategyFor(String type) {
        Type rtype = Type.valueOf(type.toUpperCase());
        return rtype.getStrategy();
    }
    */

    // Zwichenschritt 1: Enum einführen
    enum Type {
        STANDARD(new StandardStrategy()),
        PREMIUM(new PremiumStrategy()),
        VIP(new VIPStrategy());

        private final PricingStrategy strategy;

        Type(PricingStrategy strategy) {
            this.strategy = strategy;
        }

        public PricingStrategy getStrategy() {
            return strategy;
        }
    }

    // Keine Änderung am nach außen sichtbaren Verhalten!
    public static void main(String[] args) {
        var standardPrice = calculatePrice(new Order("STANDARD", 10));
        System.out.println("standardPrice: " + standardPrice);

        var premiumPrice = calculatePrice(new Order("PREMIUM", 10));
        System.out.println("premiumPrice: " + premiumPrice);

        var vipPrice = calculatePrice(new Order("VIP", 10));
        System.out.println("vipPrice: " + vipPrice);
    }
}

package zzz_bonus_refactoring_to_patterns.solutions.ex2_type_checks_composite;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public interface ProjectComponent {
    double calculateCost();
}

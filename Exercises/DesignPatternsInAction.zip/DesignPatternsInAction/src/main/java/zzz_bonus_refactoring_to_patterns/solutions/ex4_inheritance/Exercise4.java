package zzz_bonus_refactoring_to_patterns.solutions.ex4_inheritance;


/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Exercise4 {

    static interface MessageService {
        String send(String msg);
    }

    static class BasicMessageService implements MessageService {

        public String send(String msg) {
            return msg;
        }
    }

    static abstract class BaseDecorator implements MessageService {
        protected final MessageService delegate;

        BaseDecorator(MessageService delegate) {
            this.delegate = delegate;
        }
    }

    static class LoggingDecorator extends BaseDecorator {

        LoggingDecorator(MessageService delegate) {
            super(delegate);
        }

        public String send(String msg) {
            var result = delegate.send(msg);
            System.out.println("Log: " + result);
            return result;
        }
    }

    static class EncryptingDecorator extends BaseDecorator {

        EncryptingDecorator(MessageService delegate) {
            super(delegate);
        }

        public String send(String msg) {
            var result = delegate.send(msg);
            return encrypt(result);
        }

        public String encrypt(String msg) {
            return "--- " + msg + " ---";
        }
    }

    static class NormalizingDecorator extends BaseDecorator {

        NormalizingDecorator(MessageService delegate) {
            super(delegate);
        }

        public String send(String msg) {
            var result = delegate.send(msg);
            return normalize(result);
        }

        public String normalize(String msg) {
            return msg.replaceAll("[\\s\\.!\\+\\-,]", "");
        }
    }

    public static void main(String[] args) {
        MessageService logMsgService = new LoggingDecorator(new BasicMessageService());
        MessageService encryptMsgService = new EncryptingDecorator(new BasicMessageService());
        MessageService combinedService = new LoggingDecorator(new EncryptingDecorator(new BasicMessageService()));
        MessageService combinedService2 = new EncryptingDecorator(new LoggingDecorator(new BasicMessageService()));

        MessageService combinedService3 = new LoggingDecorator(new EncryptingDecorator(new NormalizingDecorator(new BasicMessageService())));


        System.out.println("encryptMsgService");
        encryptMsgService.send("Hello World!");
        System.out.println("logMsgService");
        logMsgService.send("Hello World!");

        System.out.println("combined");
        combinedService.send("Hello World!");
        System.out.println("combined2");
        combinedService2.send("Hello World!");

        System.out.println("combinedService3");
        combinedService3.send("    ,,, Hello World! ... bla + - !!! no content   ");
    }
}

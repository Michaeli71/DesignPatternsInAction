package zzz_bonus_refactoring_to_patterns.solutions.ex1_if_else_strategy;

import zzz_bonus_refactoring_to_patterns.common.Order;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Exercise1_Solution {

    // Strategy-Pattern
    interface PricingStrategy {
        double calculatePrice(Order order);
    }

    record StandardStrategy() implements PricingStrategy {
        public double calculatePrice(Order order) {
            return order.amount();
        }
    }

    record PremiumStrategy() implements PricingStrategy {
        public double calculatePrice(Order order) {
            return order.amount() * 0.9;
        }
    }

    record VIPStrategy() implements PricingStrategy {
        public double calculatePrice(Order order) {
            return order.amount() * 0.8;
        }
    }

    static double calculatePrice(Order order) {
        var pricingStrategy = strategyFor(order.type());

        return pricingStrategy.calculatePrice(order);
    }

    // was ist das für ein Pattern??? => Factory-Method
    static PricingStrategy strategyFor(String type) {
        return switch (type) {
            case "STANDARD" -> new StandardStrategy();
            case "PREMIUM" -> new PremiumStrategy();
            case "VIP" -> new VIPStrategy();
            default -> throw new IllegalArgumentException("Invalid order type");
        };
    }

    // Keine Änderung am nach außen sichtbaren Verhalten!
    public static void main(String[] args) {
        var standardPrice = calculatePrice(new Order("STANDARD", 10));
        System.out.println("standardPrice: " + standardPrice);

        var premiumPrice = calculatePrice(new Order("PREMIUM", 10));
        System.out.println("premiumPrice: " + premiumPrice);

        var vipPrice = calculatePrice(new Order("VIP", 10));
        System.out.println("vipPrice: " + vipPrice);
    }
}

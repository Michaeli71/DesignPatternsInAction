package zzz_bonus_refactoring_to_patterns.solutions.ex2_type_checks_composite;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Exercise2_Solution {

    public static void main(String[] args) {

        ProjectGroup main = new ProjectGroup();
        Project five = new Project(5);
        Project two = new Project(2);
        main.add(five);
        main.add(two);
        System.out.println("main costs: " + main.calculateCost());

        ProjectGroup subGroup = new ProjectGroup();
        Project seven = new Project(7);
        Project three = new Project(3);
        subGroup.add(seven);
        subGroup.add(three);

        main.add(subGroup);
        System.out.println("subGroup costs: " + subGroup.calculateCost());
        System.out.println("main costs: " + main.calculateCost());
    }
}

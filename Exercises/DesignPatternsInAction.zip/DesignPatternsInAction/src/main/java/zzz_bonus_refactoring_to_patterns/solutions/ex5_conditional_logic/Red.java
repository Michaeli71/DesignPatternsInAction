package zzz_bonus_refactoring_to_patterns.solutions.ex5_conditional_logic;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public record Red() implements TrafficLightState {
    @Override
    public TrafficLightState next() {
        return new Green();
    }
}

package zzz_bonus_refactoring_to_patterns.solutions.ex3_object_creation_factory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public enum DocumentType {
    WORD, LATEX, PDF;
}

package zzz_bonus_refactoring_to_patterns.solutions.ex3_object_creation_factory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Exercise3_Solution_V2 {

    // Enum DocumentType erstellen
    // Refactoring "Move Member" x 3

    // Refactoring: Extract Delegate ...
    /*
    static BaseDocument createDocument(String type) {
        if (type.equals("PDF")) {
            return new PdfDocument();
        } else if (type.equals("WORD")) {
            return new WordDocument();
        } else if (type.equals("LaTeX")) {

            return new LaTexDocument();
        }
        throw new IllegalArgumentException("Unknown type");
    }
     */

    public static void main(String[] args) {
        System.out.println("createDocument LaTeX: " + DocumentFactory_V2.createDocument(DocumentType.LATEX));
        System.out.println("createDocument WORD: " + DocumentFactory_V2.createDocument(DocumentType.WORD));
        System.out.println("createDocument PDF: " + DocumentFactory_V2.createDocument(DocumentType.PDF));
    }
}

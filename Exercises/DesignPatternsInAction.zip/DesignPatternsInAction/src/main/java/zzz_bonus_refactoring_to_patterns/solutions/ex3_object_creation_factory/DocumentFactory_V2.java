package zzz_bonus_refactoring_to_patterns.solutions.ex3_object_creation_factory;

import zzz_bonus_refactoring_to_patterns.common.BaseDocument;
import zzz_bonus_refactoring_to_patterns.common.LaTexDocument;
import zzz_bonus_refactoring_to_patterns.common.PdfDocument;
import zzz_bonus_refactoring_to_patterns.common.WordDocument;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class DocumentFactory_V2 {
    static BaseDocument createDocument(DocumentType type) {
        return switch (type) {
            case WORD -> new WordDocument();
            case LATEX -> new LaTexDocument();
            case PDF -> new PdfDocument();
            default -> throw new IllegalArgumentException("Unknown type");
        };
    }
}
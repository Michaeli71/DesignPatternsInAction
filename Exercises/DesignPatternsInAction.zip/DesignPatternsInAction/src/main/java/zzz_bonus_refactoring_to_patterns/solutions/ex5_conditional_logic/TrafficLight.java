package zzz_bonus_refactoring_to_patterns.solutions.ex5_conditional_logic;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
class TrafficLight {

    private TrafficLightState state = new Red();

    private TrafficLightState next() {
        state = state.next();
        return state;
    }

    public static void main(String[] args) {
        var trafficLight = new TrafficLight();

        System.out.println(trafficLight.next());
        System.out.println(trafficLight.next());
        System.out.println(trafficLight.next());
        System.out.println(trafficLight.next());
    }


}
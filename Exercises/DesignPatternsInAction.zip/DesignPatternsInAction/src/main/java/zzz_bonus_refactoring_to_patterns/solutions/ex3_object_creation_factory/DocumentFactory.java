package zzz_bonus_refactoring_to_patterns.solutions.ex3_object_creation_factory;

import zzz_bonus_refactoring_to_patterns.common.BaseDocument;
import zzz_bonus_refactoring_to_patterns.common.LaTexDocument;
import zzz_bonus_refactoring_to_patterns.common.PdfDocument;
import zzz_bonus_refactoring_to_patterns.common.WordDocument;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class DocumentFactory {
    static BaseDocument createDocument(String type) {
        if (type.equals("PDF")) {
            return new PdfDocument();
        } else if (type.equals("WORD")) {
            return new WordDocument();
        } else if (type.equals("LaTeX")) {
            return new LaTexDocument();
        }
        throw new IllegalArgumentException("Unknown type");
    }
}
package zzz_bonus_refactoring_to_patterns.exercises.ex1_if_else;

import zzz_bonus_refactoring_to_patterns.common.Order;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Exercise1 {

    static double calculatePrice(Order order) {
        if (order.type().equals("STANDARD")) {
            return order.amount();
        } else if (order.type().equals("PREMIUM")) {
            return order.amount() * 0.9;
        } else if (order.type().equals("VIP")) {
            return order.amount() * 0.8;
        }
        throw new IllegalArgumentException("Invalid order type");
    }

    public static void main(String[] args) {
        var standardPrice = calculatePrice(new Order("STANDARD", 10));
        System.out.println("standardPrice: " + standardPrice);

        var premiumPrice = calculatePrice(new Order("PREMIUM", 10));
        System.out.println("premiumPrice: " + premiumPrice);

        var vipPrice = calculatePrice(new Order("VIP", 10));
        System.out.println("vipPrice: " + vipPrice);
    }
}

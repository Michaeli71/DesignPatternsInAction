package zzz_bonus_refactoring_to_patterns.exercises.ex2_type_checks;

import zzz_bonus_refactoring_to_patterns.common.Project;
import zzz_bonus_refactoring_to_patterns.common.ProjectGroup;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Exercise2 {

    static double calculateCost(Object node) {
        if (node instanceof Project) {
            return ((Project) node).getCost();
        } else if (node instanceof ProjectGroup) {
            double sum = 0.0d;
            for (Object child : ((ProjectGroup) node).getProjects()) {
                sum += calculateCost(child);
            }
            return sum;
        }
        return 0.0d;
    }

    public static void main(String[] args) {

        ProjectGroup main = new ProjectGroup();
        Project five = new Project(5);
        Project two = new Project(2);
        main.addProject(five);
        main.addProject(two);
        System.out.println("main costs: " + calculateCost(main));

        ProjectGroup subGroup = new ProjectGroup();
        Project seven = new Project(7);
        Project three = new Project(3);
        subGroup.addProject(seven);
        subGroup.addProject(three);

        main.addProjectGroup(subGroup);
        System.out.println("subGroup costs: " + calculateCost(subGroup));
        System.out.println("main costs: " + calculateCost(main));
    }
}

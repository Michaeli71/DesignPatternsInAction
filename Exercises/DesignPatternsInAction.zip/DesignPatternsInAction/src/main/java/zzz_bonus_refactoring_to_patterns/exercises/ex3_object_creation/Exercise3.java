package zzz_bonus_refactoring_to_patterns.exercises.ex3_object_creation;

import zzz_bonus_refactoring_to_patterns.common.BaseDocument;
import zzz_bonus_refactoring_to_patterns.common.LaTexDocument;
import zzz_bonus_refactoring_to_patterns.common.PdfDocument;
import zzz_bonus_refactoring_to_patterns.common.WordDocument;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Exercise3 {
    static BaseDocument createDocument(String type) {
        if (type.equals("PDF")) {
            return new PdfDocument();
        } else if (type.equals("WORD")) {
            return new WordDocument();
        } else if (type.equals("LaTeX")) {
            return new LaTexDocument();
        }
        throw new IllegalArgumentException("Unknown type");
    }

    public static void main(String[] args) {
        System.out.println("createDocument LaTeX: " + createDocument("LaTeX"));
        System.out.println("createDocument WORD: " + createDocument("WORD"));
        System.out.println("createDocument PDF: " + createDocument("PDF"));
    }
}

package zzz_bonus_refactoring_to_patterns.exercises.ex5_conditional_logic;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
class TrafficLight {
    private String state = "RED";

    public String next() {
        if (state.equals("RED")) {
            state = "GREEN";
        } else if (state.equals("GREEN")) {
            state = "YELLOW";
        } else if (state.equals("YELLOW")) {
            state = "RED";
        }
        return state;
    }

    public static void main(String[] args) {
        var trafficLight = new TrafficLight();

        System.out.println(trafficLight.next());
        System.out.println(trafficLight.next());
        System.out.println(trafficLight.next());
        System.out.println(trafficLight.next());
    }
}
package zzz_bonus_refactoring_to_patterns.exercises.ex4_inheritance;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Exercise4 {

    static class MessageService {
        public String send(String msg) {
            return msg;
        }
    }

    static class LoggingMessageService extends MessageService {
        public String send(String msg) {
            System.out.println("Log: " + msg);
            return super.send(msg);
        }
    }

    static class EncryptingMessageService extends MessageService {
        public String send(String msg) {
            return encrypt(super.send(msg));
        }

        public String encrypt(String msg) {
            return "--- " + msg + " ---";
        }
    }

    static class EncryptingAndLoggingMessageService extends MessageService {
        private final EncryptingMessageService encryptingMessageService = new EncryptingMessageService();
        private final LoggingMessageService loggingMessageService = new LoggingMessageService();

        public String send(String msg) {
            return loggingMessageService.send(encryptingMessageService.send(msg));
        }
    }

    public static void main(String[] args) {
        var encryptMsgService = new EncryptingMessageService();
        var logMsgService = new LoggingMessageService();

        System.out.println("encryptMsgService");
        encryptMsgService.send("Hello World!");
        System.out.println("logMsgService");
        logMsgService.send("Hello World!");

        // Wie kombinieren ... ohje Ableitung oder Delegation
        System.out.println("combined");
        var combined = new EncryptingAndLoggingMessageService();
        combined.send("Hello World!");
    }
}

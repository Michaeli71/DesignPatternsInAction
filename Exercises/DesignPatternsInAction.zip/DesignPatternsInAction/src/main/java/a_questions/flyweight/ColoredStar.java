package a_questions.flyweight;

public record ColoredStar(String color, int radius) implements Particle {
    @Override
    public void draw(int x, int y) {
        System.out.printf("ColoredStar [Farbe=%s, x=%d, y=%d, r=%d]%n",
                color, x, y, radius);
    }
}
package a_questions.flyweight;

// Flyweight-Interface
    interface Particle {
        // intrinsischer Zustand, wird zwischen vielen Particles geteilt
        String color();
        int radius();

        // extrinsischer Zustand
        void draw(int x, int y);
    }
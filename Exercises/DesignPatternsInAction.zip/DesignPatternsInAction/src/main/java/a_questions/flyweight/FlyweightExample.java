package a_questions.flyweight;

// Beispiel Partikelsystem
// Farbe als intrisisches Zustand, der geteilt werden kann,
// Mittelpunkt-Kooridnaten und Radius als extrinsisch, beim
// Aufruf bereitstellen
public class FlyweightExample {

    public static void main(String[] args) {
        String[] colors = {"RED", "GREEN", "BLUE", "ORANGE", "SILVER"};

        // create particles
        for (String color : colors) {
            for (int radius = 1; radius <= 10; radius++) {
                ParticleFactory.getCircle(color, radius);
                ParticleFactory.getStar(color, radius);
            }
        }

        System.out.println("#circles: " + ParticleFactory.poolSizeCircles());
        System.out.println("#stars: " + ParticleFactory.poolSizeStars());

        // usage
        for (int count = 0; count < 1_000_000; count++) {
            for (String color : colors) {
                for (int radius = 1; radius <= 10; radius++) {

                    var circle = ParticleFactory.getCircle(color, radius);
                    circle.draw(count, count);

                    var star = ParticleFactory.getStar(color, radius);
                    star.draw(count, count);
                }

            }
        }

        System.out.println("#circles: " + ParticleFactory.poolSizeCircles());
        System.out.println("#stars: " + ParticleFactory.poolSizeStars());

        // dynamisch weitere Größen hinzufügen
    }
}
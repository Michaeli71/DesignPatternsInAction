package a_questions.flyweight;

public record ColorRadiusKey(String color, int radius) {}

package a_questions.flyweight;

import java.util.HashMap;
import java.util.Map;

// verwaltet den Pool geteilter Objekte ===
class ParticleFactory {
    private static final Map<ColorRadiusKey, ColoredCircle> CIRCLE_CACHE = new HashMap<>();
    private static final Map<ColorRadiusKey, ColoredStar> STRA_CACHE = new HashMap<>();

    // Particle-Flyweight mit Farbe und Radius
    public static Particle getCircle(String color, int radius) {
        ColorRadiusKey key = new ColorRadiusKey(color, radius);

        return CIRCLE_CACHE.putIfAbsent(key, new ColoredCircle(color, radius));
    }

    // Particle-Flyweight mit Farbe und Radius
    public static Particle getStar(String color, int radius) {
        ColorRadiusKey key = new ColorRadiusKey(color, radius);

        return STRA_CACHE.putIfAbsent(key, new ColoredStar(color, radius));
    }

    public static int poolSizeCircles() {
        return CIRCLE_CACHE.size();
    }

    public static int poolSizeStars() {
        return STRA_CACHE.size();
    }
}

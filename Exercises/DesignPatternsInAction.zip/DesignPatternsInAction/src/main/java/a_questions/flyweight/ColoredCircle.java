package a_questions.flyweight;

// konkretes Flyweight: speichert nur intrinsischen Zustand
public record ColoredCircle(String color, int radius) implements Particle {
    @Override
    public void draw(int x, int y) {
        System.out.printf("ColoredCircle [Farbe=%s, x=%d, y=%d, r=%d]%n",
                color, x, y, radius);
    }
}
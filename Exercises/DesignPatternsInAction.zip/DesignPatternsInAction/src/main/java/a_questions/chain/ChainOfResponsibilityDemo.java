package a_questions.chain;


import java.util.List;

enum PayloadType {
    ORDER, OFFER, ADDRESS_CHANGE, UNKNOWN
}

record Payload(PayloadType type, String content) {
}

abstract class Handler {
    protected Handler next;

    public Handler setNext(Handler next) {
        this.next = next;
        return next; // für method chaining
    }

    public boolean handleRequest(Payload request) {
        if (next != null) {
            return next.handleRequest(request);
        } else {
            //System.out.println("Kein Handler konnte die Anfrage verarbeiten: " + request);
            return false;
        }
    }
}

class OrderHandler extends Handler {
    @Override
    public boolean handleRequest(Payload request) {
        if (request.type() == PayloadType.ORDER) {
            System.out.println("OrderHandler: Processing order");
            return true;
        } else {
            super.handleRequest(request);
            return false;
        }
    }
}

class OfferHandler extends Handler {
    @Override
    public boolean handleRequest(Payload request) {
        if (request.type() == PayloadType.OFFER) {
            System.out.println("OfferHandler: Preparing offer");
            return true;
        } else {
            super.handleRequest(request);
            return false;
        }
    }
}

class AddressChangeHandler extends Handler {
    @Override
    public boolean handleRequest(Payload request) {
        if (request.type() == PayloadType.ADDRESS_CHANGE) {
            System.out.println("AddressChangeHandler: Changing Address");
            return true;
        } else {
            super.handleRequest(request);
            return false;
        }
    }
}

class DefaultHandler extends Handler {
    @Override
    public boolean handleRequest(Payload request) {
        System.out.println("DefaultHandler: " + request);
        return true;
    }
}

// === Client/Demo ===
public class ChainOfResponsibilityDemo {
    public static void main(String[] args) {

        // einzelne Handler
        Handler offerHandler = new OfferHandler();
        Handler orderHandler = new OrderHandler();
        Handler addressChangeHandler = new AddressChangeHandler();
        Handler defaultHandler = new DefaultHandler();

        // Kette aufbauen
        // entweder so, oder als Liste von Handlern, s.u.
        offerHandler.setNext(orderHandler).setNext(addressChangeHandler).setNext(defaultHandler);


        // Verschiedene Anfragen
        offerHandler.handleRequest(new Payload(PayloadType.OFFER, "Fantastic Offer"));
        offerHandler.handleRequest(new Payload(PayloadType.ORDER, "Order"));
        offerHandler.handleRequest(new Payload(PayloadType.ADDRESS_CHANGE, "ADDR CHANGE"));
        offerHandler.handleRequest(new Payload(PayloadType.UNKNOWN, "UNKNOWN"));

        // Kette lösen
        offerHandler.setNext(null);
        orderHandler.setNext(null);
        addressChangeHandler.setNext(null);

        // Schönere Variante
        List<Handler> handlers = List.of(offerHandler, orderHandler, addressChangeHandler, defaultHandler);
        handle(handlers, new Payload(PayloadType.OFFER, "Fantastic Offer"));
        handle(handlers, new Payload(PayloadType.ORDER, "Order"));
        handle(handlers, new Payload(PayloadType.ADDRESS_CHANGE, "ADDR CHANGE"));
        handle(handlers, new Payload(PayloadType.UNKNOWN, "UNKNOWN"));

    }

    private static void handle(List<Handler> handlers, Payload payload) {
        for (Handler handler : handlers) {
            boolean handled = handler.handleRequest(payload);
            if (handled)
                break;
        }
    }
}

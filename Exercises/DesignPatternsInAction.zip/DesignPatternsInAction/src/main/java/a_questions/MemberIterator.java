package a_questions;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class MemberIterator implements Iterator<Field> {
    private String info = "INFO";
    private List<String> names = List.of("aahj", "hdsjhsdhj", "jkjksd");
    private int value = 42;
    private Long deviation = 123456789L;
    private LocalDateTime timeStamp = LocalDateTime.now();


    // Datenbestand für Iterator
    private Field[] fields;
    private int position = 0;

    public MemberIterator() {
        fields = getClass().getDeclaredFields();
    }

    public MemberIterator(Class<?> clazz) {
        fields = clazz.getDeclaredFields();
    }

    @Override
    public boolean hasNext() {
        return (position < fields.length);
    }


    @Override
    public Field next() {
        Field field = fields[position];
        position++;

        return field;
        // don't do that
        // return fields[position++];
    }
}

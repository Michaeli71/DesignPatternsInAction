package a_questions;

import java.lang.reflect.Field;
import java.util.Iterator;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class MemberIteratorExample
{    
    public static void main(String[] args) throws IllegalArgumentException, IllegalAccessException
    {
        Iterator<Field> it = new MemberIterator();
        while (it.hasNext())
        {
            Field field = it.next();
            field.setAccessible(true);
            System.out.println(field);
            System.out.println("Value = " + field.get(it));
        }
    }   
}

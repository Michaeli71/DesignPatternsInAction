package a_questions;

import java.lang.reflect.Field;
import java.util.Iterator;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class MemberIteratorExample {
    public static void main(String[] args) throws IllegalArgumentException, IllegalAccessException {
        var content = new MemberIterator();
        Iterator<Field> it = new MemberIterator(MemberIterator.class);
        while (it.hasNext()) {
            Field field = it.next();
            field.setAccessible(true);
            System.out.println(field);
            System.out.println("Value = " + field.get(content));
        }

        System.out.println("----------------------------------");

        // --add-opens java.base/java.lang=ALL-UNNAMED
        var content2 = "Example Value";
        Iterator<Field> it2 = new MemberIterator(content2.getClass());
        while (it2.hasNext()) {
            Field field = it2.next();
            field.setAccessible(true);
            System.out.println(field);
            System.out.println("Value = " + field.get(content2));
        }
    }
}

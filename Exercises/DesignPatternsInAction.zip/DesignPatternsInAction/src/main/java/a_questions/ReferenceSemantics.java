package a_questions;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ReferenceSemantics {

	static class Person
	{
		String name;
		int age;

		public Person(String name, int age) {
			this.name = name;
			this.age = age;
		}

		public Person(Person other) {
			this(other.name, other.age);
		}
		
		static Person copyOf(Person other)
		{
			return new Person(other);
		}
		
		@Override
		public String toString() {
			return "Person [name=" + name + ", age=" + age + "]";
		}
		
		
	}
	
	public static void main(String[] args) {
				
		final List<Person> people = new ArrayList<>();
		people.add(new Person("Mike", 50));
		people.add(new Person("John", 40));
		people.add(new Person("James", 20));

		// FALLSTRICK 1
		//doSomething(people);
		System.out.println(people);
		
		// ABHILE 1: Verändwerlichekit add / remove entfernen
		//doSomething(Collections.unmodifiableList(people));
		System.out.println(people);
		
		// FALLSTRICK 2
		List<Person> people2 = new ArrayList<>(people);
		people2.add(new Person("VALID", 1234));
		//doSomething(people2);
		System.out.println(people2);
		
		// ABHILFE: Deep copy
		// for alle Person eine Kopie erstellen
		List<Person> people3 = new ArrayList<>();
		for (Person person : people)
		{
			people3.add(Person.copyOf(person));
		}
		doSomething(people);
		System.out.println("People:" + people);
		System.out.println("People3:" + people3);
	}

	private static void doSomething(final List<Person> people) {

		// nicht möglich bei "unmodifiableList"
		// people.add(new Person("UNEXPECTED", 77));
		
		people.get(1).age = 444;
	}

}

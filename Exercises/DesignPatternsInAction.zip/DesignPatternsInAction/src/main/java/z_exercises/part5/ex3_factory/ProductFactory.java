package z_exercises.part5.ex3_factory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class ProductFactory {
    public static Product createProduct(String name) {
        switch (name) {
            case "Book":
                return new Book();
            case "Car":
                return new Car();
            case "TV":
                return new TV();
            default:
                throw new IllegalArgumentException("No such product " + name);
        }
    }


    static interface Product {
    }

    static class Book implements Product {
    }

    static class Car implements Product {
    }

    static class TV implements Product {
    }
}
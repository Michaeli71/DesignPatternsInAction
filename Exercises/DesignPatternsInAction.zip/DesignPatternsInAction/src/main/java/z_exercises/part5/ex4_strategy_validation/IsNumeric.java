package z_exercises.part5.ex4_strategy_validation;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class IsNumeric implements ValidationStrategy
{
    @Override
    public boolean validate(String input)
    {
        return input.matches("[+-]?\\d+");
    }
}
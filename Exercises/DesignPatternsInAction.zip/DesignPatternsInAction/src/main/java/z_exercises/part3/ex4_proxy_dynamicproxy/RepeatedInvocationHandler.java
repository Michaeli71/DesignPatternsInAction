package z_exercises.part3.ex4_proxy_dynamicproxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Beispielprogramm zur Definition eines InvocationHandler als Basis für einen dynamischen Proxy zur Performance-Messung
 *
 * @author Michael Inden
 * <p>
 * Copyright 2017 by Michael Inden
 */
public class RepeatedInvocationHandler implements InvocationHandler {
    private final Object target;
    private final int times;

    public RepeatedInvocationHandler(final Object target, final int times) {
        this.target = target;
        this.times = times;
    }

    @Override
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
        Object result = null;

        for (int i = 0; i < times; i++) {
            try {
                // Achtunng hier nicht versehentlich proxy übergeben
                result = method.invoke(target, args);
            } catch (InvocationTargetException ex) {
                throw ex.getTargetException();
            }
        }
        return result;
    }
}
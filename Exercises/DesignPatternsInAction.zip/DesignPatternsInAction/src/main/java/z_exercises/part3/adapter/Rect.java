package z_exercises.part3.adapter;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Rect extends BaseFigure {
    @Override
    void draw() {
        System.out.println("Draw rect");
    }

    @Override
    void fill() {
        System.out.println("Fill rect");
    }
}

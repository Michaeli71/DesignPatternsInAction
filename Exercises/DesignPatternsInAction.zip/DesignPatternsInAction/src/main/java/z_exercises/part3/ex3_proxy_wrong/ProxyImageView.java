package z_exercises.part3.ex3_proxy_wrong;

import javax.swing.*;
import java.awt.*;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class ProxyImageView extends JComponent implements ImageView {
    private RealImageView realImage;
    private String fileName;

    public ProxyImageView(String fileName) {
        this.fileName = fileName;

        setPreferredSize(new Dimension(40, 40));
    }

    @Override
    public void paintComponent(Graphics g) {
        display(g);
    }

    @Override
    public void display(Graphics g) {
        if (realImage == null) {
            // Platzhalter malen
            if (g != null) {
                final Dimension componentSize = getSize();
                g.setColor(Color.BLUE);
                g.fillRect(0, 0, componentSize.width, componentSize.height);
            }

            // potenziell längerdauernd ... problematisch mit UI !!!
            realImage = new RealImageView(fileName);
        } else {
            realImage.display(g);
        }
    }
}
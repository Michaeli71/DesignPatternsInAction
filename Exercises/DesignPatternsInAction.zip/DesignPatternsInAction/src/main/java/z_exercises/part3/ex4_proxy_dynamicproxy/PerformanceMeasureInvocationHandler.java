package z_exercises.part3.ex4_proxy_dynamicproxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

/**
 * Beispielprogramm zur Definition eines InvocationHandler als Basis für einen dynamischen Proxy zur Performance-Messung
 *
 * @author Michael Inden
 * <p>
 * Copyright 2017 by Michael Inden
 */
public class PerformanceMeasureInvocationHandler implements InvocationHandler {
    private final Object target;

    public PerformanceMeasureInvocationHandler(final Object target) {
        this.target = target;
    }

    @Override
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
        final long startTime = System.nanoTime();

        Object result = null;
        try {
            // Achtunng hier nicht versehentlich proxy übergeben
            result = method.invoke(target, args);
        } catch (InvocationTargetException ex) {
            throw ex.getTargetException();
        }

        printExecTime(method.getName(), System.nanoTime() - startTime);

        return result;
    }

    private void printExecTime(final String methodName, final long duration) {
        System.out.println("Method call of '" + methodName + "' took: " + TimeUnit.NANOSECONDS.toMillis(duration) + " ms");
    }
}
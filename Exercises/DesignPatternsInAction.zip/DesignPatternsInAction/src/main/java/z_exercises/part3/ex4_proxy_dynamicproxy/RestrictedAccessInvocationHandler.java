package z_exercises.part3.ex4_proxy_dynamicproxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

import z_solutions.part3.ex4_proxy_dynamicproxy.InvalidAccessRightsException;
import z_solutions.part3.ex4_proxy_dynamicproxy.LoggedInUserService;

// STEP 2: create class
public class RestrictedAccessInvocationHandler implements InvocationHandler {

	private final Map<String, Integer> origMap;
	
	public RestrictedAccessInvocationHandler(Map<String, Integer> modifiableMap) {
		this.origMap = modifiableMap;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		Object result = null;

		// DELEGATE CALL
		try
        {
            // Achtung hier nicht versehentlich proxy übergeben
            result = method.invoke(origMap, args);
        }
        catch (InvocationTargetException ex)
        {
            throw ex.getTargetException();
        }
		
        return result;
	}
	
	// STEP 3: copy from RestrictedAccessMap
	public void ensureAccessGranted() throws InvalidAccessRightsException
    {
        System.out.println("checking ensureAccessGranted()");

        if (!LoggedInUserService.INSTANCE.getLoggedInUser().equals("ADMIN"))
            throw new InvalidAccessRightsException("Invalid User");
    }
}

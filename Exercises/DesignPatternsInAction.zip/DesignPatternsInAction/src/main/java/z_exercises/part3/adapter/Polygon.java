package z_exercises.part3.adapter;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Polygon {
    void paintBorder() {
        System.out.println("paintBorder");
    }

    void filledWithPattern() {
        System.out.println("filledWithPattern");
    }
}
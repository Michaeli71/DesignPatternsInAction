package z_exercises.part3.ex3_proxy_wrong;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ProxyPatternExample
{
    public static void main(String[] args)
    {
        final JFrame frame = new JFrame("ProxyPatternExample");
        final String[] tileFileNames = { "tiles/tile_gras_1.jpg", "tiles/tile_gras_2.jpg", "tiles/tile_rock_1.jpg",
                                         "tiles/tile_rock_2.jpg", "tiles/tile_water.jpg", 
                                         "tiles/tile_coast_n.jpg", "tiles/tile_coast_nw.jpg", "tiles/tile_coast_w.jpg"};

        final JPanel contentPanel = new JPanel();
        for (String imageTileName : tileFileNames)
        {
            contentPanel.add(new ProxyImageView(imageTileName));
        }

        frame.setContentPane(contentPanel);
        frame.setSize(500, 300);
        frame.setVisible(true);
    }

}
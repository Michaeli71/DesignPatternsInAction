package z_exercises.part3.ex4_proxy_dynamicproxy;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class RestrictedAccessMap<K, V> implements Map<K, V> {

    private final Map<K, V> underlyingMap = new HashMap<>();

    public void ensureAccessGranted() throws InvalidAccessRightsException {
        if (!LoggedInUserService.INSTANCE.getLoggedInUser().equals("ADMIN"))
            throw new InvalidAccessRightsException("Invalid User");
    }

    @Override
    public V put(final K key, final V value) {
        ensureAccessGranted();
        return underlyingMap.put(key, value);
    }

    @Override
    public int size() {
        ensureAccessGranted();
        return underlyingMap.size();
    }

    @Override
    public boolean isEmpty() {
        ensureAccessGranted();
        return underlyingMap.isEmpty();
    }

    @Override
    public boolean containsKey(Object key) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean containsValue(Object value) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public V get(Object key) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public V remove(Object key) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> m) {
        // TODO Auto-generated method stub

    }

    @Override
    public void clear() {
        // TODO Auto-generated method stub

    }

    @Override
    public Set<K> keySet() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Collection<V> values() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Set<Entry<K, V>> entrySet() {
        // TODO Auto-generated method stub
        return null;
    }
}
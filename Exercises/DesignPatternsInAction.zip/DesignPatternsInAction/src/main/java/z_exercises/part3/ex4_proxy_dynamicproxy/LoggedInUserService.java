package z_exercises.part3.ex4_proxy_dynamicproxy;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class LoggedInUserService {
    public static LoggedInUserService INSTANCE = new LoggedInUserService();

    private String loggedInUser = "";

    public String getLoggedInUser() {
        return loggedInUser;
    }

    public void setLoggedInUser(String loggedInUser) {
        this.loggedInUser = loggedInUser;
    }
}

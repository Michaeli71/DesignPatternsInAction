package z_exercises.part3.ex3_proxy_wrong;

import java.awt.*;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public interface ImageView {
    void display(Graphics g);
}
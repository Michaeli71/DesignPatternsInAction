package z_exercises.part3.ex4_proxy_dynamicproxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.security.Provider.Service;
import java.util.HashMap;
import java.util.Map;

public class RestrictedAccessExample 
{
	public static void main(final String[] args)
	{
	    LoggedInUserService.INSTANCE.setLoggedInUser("ADMIN");
		
	    var origValues = Map.of("Mike", 50, "Tim", 50, "Peter", 42);
	    var modifiableMap = new HashMap<>(origValues);
	    var restrictedMap = createRestricetdAccessMap(modifiableMap);
	    
	    System.out.println(restrictedMap.size());
	    restrictedMap.size();
	    restrictedMap.entrySet();
	    restrictedMap.put("LDM", 6);
	    restrictedMap.putAll(Map.of("ALF", 6, "Micha", 47));
	    System.out.println(restrictedMap.size());
	}

	// STEP 1:
	private static Map<String, Integer> createRestricetdAccessMap(Map<String, Integer> modifiableMap) {
	
	    final InvocationHandler handler = new RestrictedAccessInvocationHandler(modifiableMap);
	
	    final Class<?>[] proxyInterfaces = { Map.class };
	    //return (Map) Proxy.newProxyInstance(Service.class.getClassLoader(), proxyInterfaces, handler);
	    Map<String, Integer> proxiedMap = (Map<String, Integer>) Proxy.newProxyInstance(Service.class.getClassLoader(), proxyInterfaces, handler);
	    
	    // Add on:
	    final InvocationHandler handler2 = new LoggingInvocationHandler(proxiedMap);
	    final Class<?>[] proxyInterfaces2 = { Map.class };
	    //return (Map) Proxy.newProxyInstance(Service.class.getClassLoader(), proxyInterfaces2, handler2);
	    Map<String, Integer> proxiedMap2 = (Map<String, Integer>) Proxy.newProxyInstance(Service.class.getClassLoader(), proxyInterfaces2, handler2);
//	    return proxiedMap2;
	    
//	    // Add on 2:
	   // final InvocationHandler handler3 = new LoggingInvocationHandler(proxiedMap2);
	    final InvocationHandler handler3 = new RepeatedInvocationHandler(proxiedMap2, 5);
	    final Class<?>[] proxyInterfaces3 = { Map.class };
	    //return (Map) Proxy.newProxyInstance(Service.class.getClassLoader(), proxyInterfaces2, handler2);
	    Map<String, Integer> proxiedMap3 = (Map<String, Integer>) Proxy.newProxyInstance(Service.class.getClassLoader(), proxyInterfaces3, handler3);
	    
//	    // Add on 3:
	    final InvocationHandler handler4 = new PerformanceMeasureInvocationHandler(proxiedMap3);	    
	    final Class<?>[] proxyInterfaces4 = { Map.class };
	    return (Map) Proxy.newProxyInstance(Service.class.getClassLoader(), proxyInterfaces4, handler4);
	}
}


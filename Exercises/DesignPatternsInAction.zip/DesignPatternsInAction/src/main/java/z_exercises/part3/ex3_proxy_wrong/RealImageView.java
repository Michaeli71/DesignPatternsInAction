package z_exercises.part3.ex3_proxy_wrong;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class RealImageView extends JComponent implements ImageView {
    private String fileName;
    private Image image;

    public RealImageView(String fileName) {
        this.fileName = fileName;
        try {
            loadFromDisk(fileName);

            setPreferredSize(new Dimension(40, 40));
        } catch (IOException e) {
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        display(g);
    }

    @Override
    public void display(Graphics g) {
        final Dimension componentSize = getSize();
        g.setColor(Color.RED);
        g.fillRect(0, 0, componentSize.width, componentSize.height);

        System.out.println("drawImage " + fileName);
        g.drawImage(image, 0, 0, null);
    }

    private void loadFromDisk(String fileName) throws IOException {
        System.out.println("Loading " + fileName);

        final File imageFile = new File("src/main/resources", fileName);
        this.image = ImageIO.read(imageFile);

        // slow down to show effect
        try {
            Thread.sleep(1_000);
        } catch (InterruptedException e) {
        }
    }
}
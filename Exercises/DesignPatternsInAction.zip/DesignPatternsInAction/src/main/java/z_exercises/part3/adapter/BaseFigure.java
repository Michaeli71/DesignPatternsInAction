package z_exercises.part3.adapter;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public abstract class BaseFigure 
{
	abstract void draw();
	abstract void fill();
}

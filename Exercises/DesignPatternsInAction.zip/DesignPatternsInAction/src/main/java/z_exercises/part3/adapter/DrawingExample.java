package z_exercises.part3.adapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class DrawingExample {
    public static void main(String[] args) {
        List<BaseFigure> figures = new ArrayList<>();
        figures.add(new Circle());
        figures.add(new Circle());
        figures.add(new Rect());

        // how to use/drawTriangle
        // how to use/draw Polygon

        //
        for (BaseFigure fig : figures) {
            fig.draw();
        }
    }
}

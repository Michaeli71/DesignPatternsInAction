package z_exercises.part4.ex1_iterator;

import java.util.Iterator;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class RandomListIteratorV1<E> implements Iterator<E>
{
    RandomListIteratorV1(List<E> values)
    {
    }

    @Override
    public boolean hasNext()
    {
        return false;
    }

    @Override
    public E next()
    {
        return null;
    }

    public static void main(String[] args)
    {
        List<Integer> values = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        Iterator<Integer> it = new RandomListIteratorV1<>(values);
        while (it.hasNext())
        {
            System.out.println(it.next());
        }
    }
}
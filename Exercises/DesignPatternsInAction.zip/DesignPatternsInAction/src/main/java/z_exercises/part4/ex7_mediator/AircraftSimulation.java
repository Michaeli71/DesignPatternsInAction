package z_exercises.part4.ex7_mediator;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class AircraftSimulation {
    public static void main(String[] args) {
        Tower towerNY = new Tower("New York");
        Tower towerPH = new Tower("Philadelphia");

        Aircraft flight1 = new Aircraft("Airbus A380", towerNY);
        Aircraft flight2 = new Aircraft("Boeing 737", towerNY);
        Aircraft flight3 = new Aircraft("FC04", towerPH);
        Aircraft flight4 = new Aircraft("Boeing 747", towerNY);

        // TODO
    }
}

package z_exercises.part4.ex7_mediator;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Tower {

    private final String name;
    private final List<Aircraft> aircrafts = new ArrayList<>();

    public Tower(String name) {
        this.name = name;

    }

    public void registerAircraft(Aircraft aircraft) {
        aircrafts.add(aircraft);
    }

    public void deregisterAircraft(Aircraft aircraft) {
        aircrafts.remove(aircraft);
    }

    // TODO
}

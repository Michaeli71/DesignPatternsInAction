package z_exercises.part4.ex7_mediator;

import java.util.Objects;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Aircraft {
    private final String name;

    private Tower tower;

    private int currentAltitude;

    protected Aircraft(String name, Tower tower) {
        this.name = name;
        this.tower = tower;

        // potenziell gefährlich mit Escaping Reference
        // Lösung: ??? => DISKUSSION
        tower.registerAircraft(this);
    }

    public void receiveNotification(String msg) {
        System.out.println(name + " received " + msg);
    }

    public void notifyTower(String msg) {
        // TODO
    }

    public Tower getTower() {
        return tower;
    }

    public void setTower(Tower tower) {
        this.tower = tower;
    }

    public int getCurrentAltitude() {
        return currentAltitude;
    }

    public void setCurrentAltitude(int currentAltitude) {
        this.currentAltitude = currentAltitude;
    }

    public String getName() {
        return name;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Aircraft other = (Aircraft) obj;
        return Objects.equals(name, other.name);
    }
}

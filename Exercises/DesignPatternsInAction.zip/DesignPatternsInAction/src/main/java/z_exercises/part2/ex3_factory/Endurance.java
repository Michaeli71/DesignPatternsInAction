package z_exercises.part2.ex3_factory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Endurance implements Workout {
    @Override
    public void createWorkout() {
        System.out.println("Created Endurance workout that includes:");
        System.out.println("1. Running");
        System.out.println("2. Skating");
        System.out.println("3. Cycling");
    }
}
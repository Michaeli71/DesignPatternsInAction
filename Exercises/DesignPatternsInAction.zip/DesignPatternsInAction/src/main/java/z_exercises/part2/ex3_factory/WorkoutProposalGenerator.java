package z_exercises.part2.ex3_factory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class WorkoutProposalGenerator {
 
    public static void main(String[] args) {

    	// TODO
    }
}
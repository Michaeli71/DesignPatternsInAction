package z_exercises.part2.ex3_factory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class UpperBody implements Workout {
    @Override
    public void createWorkout() {
        System.out.println("Created Upper Body Workout that includes:");
        System.out.println("1. Breast");
        System.out.println("2. Biceps");
        System.out.println("3. Triceps");
    }
}
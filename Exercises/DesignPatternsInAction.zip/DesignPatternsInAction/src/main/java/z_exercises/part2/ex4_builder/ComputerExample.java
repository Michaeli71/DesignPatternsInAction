package z_exercises.part2.ex4_builder;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class ComputerExample {
    public static void main(String[] args) {
        Computer iMac2020 = new Computer("2 TB", "72 GB", true, true);

        Computer oldCompi = new Computer("500 GB", "2 GB", true, false);

        System.out.println(iMac2020);
        System.out.println(oldCompi);
    }
}

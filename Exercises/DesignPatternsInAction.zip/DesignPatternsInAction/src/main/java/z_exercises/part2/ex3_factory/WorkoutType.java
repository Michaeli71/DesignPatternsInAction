package z_exercises.part2.ex3_factory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public enum WorkoutType {
    UPPERBODY, LOWERBODY, ENDURANCE;
}
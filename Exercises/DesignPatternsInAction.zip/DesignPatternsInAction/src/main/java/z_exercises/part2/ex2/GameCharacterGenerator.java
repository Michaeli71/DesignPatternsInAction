package z_exercises.part2.ex2;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class GameCharacterGenerator
{
    public static void main(String[] args)
    {
        Ufo ufo = new Ufo();
        Bullet bullet = new Bullet();
        Player player = new Player();
    }

    static class Ufo
    {

    }

    static class Bullet
    {

    }

    static class Player
    {

    }

}

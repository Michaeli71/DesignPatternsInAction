package z_exercises.part2.ex1;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class PizzaCreator {

    public static void main(String[] args) {

        String type = "Surprise";

        Pizza pizza;
        if (type.equalsIgnoreCase("Napoli"))
            pizza = new PizzaNapoli();
        if (type.equalsIgnoreCase("Funghi"))
            pizza = new PizzaFunghi();
        if (type.equalsIgnoreCase("Surprise"))
            pizza = new PizzaSurprise();

        // Probelmatisch bzgl. OPEN CLOSED PRINCIPLE
        // Margherita
        // Peperoni
        // ...
    }

    static interface Pizza {
    }

    static class PizzaNapoli implements Pizza {

    }

    static class PizzaFunghi implements Pizza {

    }

    static class PizzaSurprise implements Pizza {

    }
}

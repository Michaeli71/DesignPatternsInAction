package part2.entwurfsmuster.creational.prototype;

import java.awt.*;

/**
 * Die Klasse <code>AbstractGraphicsElement</code> modelliert eine Basisklasse f�r
 * grafische Figuren, die eine Position besitzen.
 *
 * @author Michael Inden
 * <p>
 * Copyright 2011 by Michael Inden
 */
public abstract class AbstractGraphicsElement {
    private Point pos;

    public AbstractGraphicsElement(int x, int y) {
        pos = new Point(x, y);
    }

    public abstract AbstractGraphicsElement makeCopy();

    public final Point getPosition() {
        return pos;
    }

    public void setPosition(int x, int y) {
        pos = new Point(x, y);
    }

    public abstract void draw(final Graphics2D g2D);
}

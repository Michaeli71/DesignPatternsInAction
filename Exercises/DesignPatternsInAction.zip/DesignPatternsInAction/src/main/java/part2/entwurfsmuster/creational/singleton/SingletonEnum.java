package part2.entwurfsmuster.creational.singleton;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public enum SingletonEnum {
    INSTANCE;

    private int attribute1;
    private int attribute2;

    public void businessMethod1() { /* ... */ }

    public void businessMethod2() { /* ... */ }
}
package part2.entwurfsmuster.creational.singleton;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public final class BadSingleton 
{
	private static BadSingleton INSTANCE = null;
	
	private int attribute1;
	private int attribute2;

	// ACHTUNG: SCHLECHT !!!
	public static BadSingleton getInstance() 
	{
		if (INSTANCE == null) {
			INSTANCE = new BadSingleton();
		}
		return INSTANCE;
	}

	private BadSingleton() {
	}

	public void businessMethod1() { /* ... */ }
	public void businessMethod2() { /* ... */ }
}
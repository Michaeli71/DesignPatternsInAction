package part2.entwurfsmuster.creational.factorymethod;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class SimpleProductFactory 
{
	public static Product createProduct(String name) 
	{
		switch (name) {
		case "book":
			return new Book();
		case "pizza":
			return new Pizza();
		case "car":
			return new Car();
		default:
			throw new RuntimeException("No such product " + name);
		}
	}

	
    static interface Product {}
    static class Book implements Product {}
    static class Pizza implements Product {}
    static class Car implements Product {}
}

package z_solutions.part3.ex4_proxy_dynamicproxy;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class InvalidAccessRightsException extends RuntimeException {
    public InvalidAccessRightsException(String msg) {
        super(msg);
    }
}

package z_solutions.part3.ex4_proxy_dynamicproxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.stream.Collectors;

/**
 * Beispielprogramm zur Definition eines InvocationHandler als Basis für einen dynamischen Proxy zur Performance-Messung
 * 
 * @author Michael Inden
 * 
 * Copyright 2017 by Michael Inden 
 */
public class LoggingInvocationHandler implements InvocationHandler
{
    private Object target;

    public LoggingInvocationHandler(final Object target)
    {
        this.target = target;
    }

    @Override
    public Object invoke(final Object proxy, final Method mmethod, final Object[] args) throws Throwable
    {
        String parameters = "";
        if (args != null)
            parameters = Arrays.stream(args).map(Object::toString).collect(Collectors.joining(","));

        System.out.println("Invoking " + mmethod.getName() + "(" + parameters + ")");
        return mmethod.invoke(target, args);
    }
}
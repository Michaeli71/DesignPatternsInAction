package z_solutions.part3.ex4_proxy_dynamicproxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Map;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class AccessControlProxy<K, V> implements InvocationHandler {
    private final Map<K, V> map;

    public AccessControlProxy(final Map<K, V> map) {
        this.map = map;
    }

    public void ensureAccessGranted() throws InvalidAccessRightsException {
        System.out.println("checking ensureAccessGranted()");

        if (!LoggedInUserService.INSTANCE.getLoggedInUser().equals("ADMIN"))
            throw new InvalidAccessRightsException("Invalid User");
    }

    @Override
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
        System.out.println("Checking for method: " + method);
        ensureAccessGranted();

        // BEFORE

        Object result = null;
        try {
            // Achtung hier nicht versehentlich proxy übergeben
            result = method.invoke(map, args);
        } catch (InvocationTargetException ex) {
            throw ex.getTargetException();
        }

        // AFTER

        return result;
    }

    static <K, V> Map<K, V> createRestricetdAccessMap(Map<K, V> origValues) {
        final InvocationHandler handler = new AccessControlProxy<>(origValues);

        final Class<?>[] proxyInterfaces = {Map.class};
        return (Map<K, V>) Proxy.newProxyInstance(Map.class.getClassLoader(), proxyInterfaces, handler);
    }

    // BONUS:

    static <K, V> Map<K, V> createRestricetdAccessMapWithLogging(Map<K, V> origValues) {
        final InvocationHandler handler = new AccessControlProxy<>(origValues);

        final Class<?>[] proxyInterfaces = {Map.class};
        Map<K, V> map = (Map<K, V>) Proxy.newProxyInstance(Map.class.getClassLoader(), proxyInterfaces, handler);

        InvocationHandler handler2 = new LoggingInvocationHandler(map);
        return (Map<K, V>) Proxy.newProxyInstance(Map.class.getClassLoader(), proxyInterfaces, handler2);

    }
}

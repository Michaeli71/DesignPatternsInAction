package z_solutions.part3.adapter;

import java.util.Objects;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class TriangleAdapter extends BaseFigure {
    private final Triangle triangle;

    TriangleAdapter(final Triangle triangle) {
        this.triangle = Objects.requireNonNull(triangle);
    }

    @Override
    void draw() {
        triangle.drawTriangle();
    }

    @Override
    void fill() {
        triangle.fillTriangle();
    }
}

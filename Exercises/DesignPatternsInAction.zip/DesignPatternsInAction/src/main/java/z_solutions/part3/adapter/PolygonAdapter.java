package z_solutions.part3.adapter;

import java.util.Objects;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class PolygonAdapter extends BaseFigure
{
    private final Polygon polygon;

    PolygonAdapter(final Polygon polygon)
    {
        this.polygon = Objects.requireNonNull(polygon);;
    }

    @Override
    void draw()
    {
        polygon.paintBorder();
    }

    @Override
    void fill()
    {
        polygon.filledWithPattern();
    }
}

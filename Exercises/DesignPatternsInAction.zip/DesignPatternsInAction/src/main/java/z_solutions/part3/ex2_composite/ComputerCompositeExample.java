package z_solutions.part3.ex2_composite;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public final class ComputerCompositeExample {
    public static void main(final String[] args) {
        ComputerComposite computer = new ComputerComposite("MY-COMPI");
        computer.add(new ComputerPart("Keyboard", 65));
        computer.add(new ComputerPart("Monitor", 450));
        ComputerPart cpu = new ComputerPart("CPU", 550);
        computer.add(cpu);
        computer.add(new ComputerPart("Memory", 250));

        // Graphics Card
        ComputerComposite graphicsCard = new ComputerComposite("Graph Card");
        ComputerPart gpu = new ComputerPart("GPU", 210);
        graphicsCard.add(gpu);
        graphicsCard.add(new ComputerPart("Memory", 170));

        computer.add(graphicsCard);



        ComputerComposite graphicsCard2 = new ComputerComposite("External Graph Card");
        ComputerPart gpu1 = new ComputerPart("GPU1", 300);
        ComputerPart gpu2 = new ComputerPart("GPU2", 300);
        graphicsCard2.add(gpu1);
        graphicsCard2.add(gpu2);
        ComputerComposite memoryBox = new ComputerComposite("Memory Box");
        memoryBox.add(new ComputerPart("Memory1", 200));
        memoryBox.add(new ComputerPart("Memory2", 200));
        graphicsCard2.add(memoryBox);

        computer.add(graphicsCard2);

        final ComputerComponent[] components = {computer, cpu, graphicsCard, graphicsCard2, memoryBox, gpu};
        for (final ComputerComponent current : components)
            printPrice(current);
    }

    private static void printPrice(final ComputerComponent projectComponent) {
        System.out.println("Price of '" + projectComponent.getName() + "': " +
                projectComponent.calcPrice());
    }

    // ...

    public static abstract class ComputerComponent {
        private final String name;

        public ComputerComponent(final String name) {
            this.name = name;
        }

        public abstract int calcPrice();

        public String getName() {
            return name;
        }
    }

    public static class ComputerPart extends ComputerComponent {
        private final int price;

        public ComputerPart(final String name, final int price) {
            super(name);
            this.price = price;
        }

        @Override
        public int calcPrice() {
            return price;
        }
    }

    public static class ComputerComposite extends ComputerComponent {
        final List<ComputerComponent> subComponents = new ArrayList<>();

        public ComputerComposite(final String name) {
            super(name);
        }

        @Override
        public int calcPrice() {
            int costs = 0;
            for (final ComputerComponent current : subComponents) {
                costs += current.calcPrice();
            }

            return costs;
        }

        public void add(final ComputerComponent computerComponent) {
            subComponents.add(computerComponent);
        }
    }
}

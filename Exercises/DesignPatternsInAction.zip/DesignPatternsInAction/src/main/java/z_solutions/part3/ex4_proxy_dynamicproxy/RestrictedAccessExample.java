package z_solutions.part3.ex4_proxy_dynamicproxy;

import java.util.HashMap;
import java.util.Map;

import static z_solutions.part3.ex4_proxy_dynamicproxy.AccessControlProxy.createRestricetdAccessMapWithLogging;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class RestrictedAccessExample {
    public static void main(final String[] args) {
        LoggedInUserService.INSTANCE.setLoggedInUser("ADMIN");

        var origValues = Map.of("Mike", 50, "Tim", 50, "Peter", 42);
        var modifiableMap = new HashMap<>(origValues);
        //var restrictedMap = createRestricetdAccessMap(modifiableMap);
        var restrictedMap = createRestricetdAccessMapWithLogging(modifiableMap);

        restrictedMap.size();
        restrictedMap.entrySet();
        restrictedMap.put("LDM", 6);
        restrictedMap.putAll(Map.of("ALF", 6, "Micha", 47));
    }
}

package z_solutions.part3.adapter;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Triangle {
    void drawTriangle() {
        System.out.println("drawTriangle");
    }

    void fillTriangle() {
        System.out.println("fillTriangle");
    }
}

package z_solutions.part3.ex3_proxy_corrected;

import javax.swing.*;
import java.util.Arrays;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class ProxyPatternExample {
    public static void main(String[] args) {
        final JFrame frame = new JFrame("ProxyPatternExample");
        final String[] tileFileNames = {"tiles/tile_gras_1.jpg", "tiles/tile_gras_2.jpg", "tiles/tile_rock_1.jpg",
                "tiles/tile_rock_2.jpg", "tiles/tile_water.jpg",
                "tiles/tile_coast_n.jpg", "tiles/tile_coast_nw.jpg", "tiles/tile_coast_w.jpg"};

        final JPanel contentPanel = new JPanel();
        System.out.println(Arrays.toString(tileFileNames));
        for (String imageTileName : tileFileNames) {
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            /*
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            contentPanel.add(new ProxyImageView(imageTileName));
            */
        }

        frame.setContentPane(contentPanel);
        frame.setSize(500, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
package z_solutions.part4.ex3_strategy_filter;

import part4.entwurfsmuster.behavioral.strategy.FilterStrategy;

import java.util.Objects;

/**
 * Utility-Klasse zur Filterung mithilfe des Strategie-Musters
 * <br>
 * Die Klasse <code>InverseFilter</code> erlaubt es beliebige Filterkriterien zu
 * invertieren. Sie ist gem�� dem Dekorierer-Muster realisiert.
 *
 * @author Michael Inden
 * <p>
 * Copyright 2011 by Michael Inden
 */
public final class Not implements FilterStrategy {
    private final FilterStrategy originalFilterStrategy;

    public Not(final FilterStrategy originalFilterStrategy) {
        this.originalFilterStrategy =
                Objects.requireNonNull(originalFilterStrategy,
                        "parameter 'originalFilterStrategy' must not be null!");
    }

    @Override
    public boolean acceptValue(final int value) {
        return !originalFilterStrategy.acceptValue(value);
    }

    @Override
    public String toString() {
        return "InverseFilter " + originalFilterStrategy;
    }
}
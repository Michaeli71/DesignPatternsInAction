package z_solutions.part4.ex3_strategy_filter;

import part4.entwurfsmuster.behavioral.strategy.FilterStrategy;

import java.util.LinkedList;
import java.util.List;

/**
 * Beispielprogramm zur Filterung mithilfe des Strategie-Musters
 * <br>
 * Die Klasse <code>StrategyFilterExample2</code> zeigt eine Filterung
 * von einer Liste von Integer-Werten.
 * Es wird hier die Kombination verschiedener Filterkriterien demonstriert.
 *
 * @author Michael Inden
 * <p>
 * Copyright 2011 by Michael Inden
 */
public final class StrategyFilterExample2 {
    public static List<Integer> filterAll(final List<Integer> inputs, final FilterStrategy filterStrategy) {
        final List<Integer> result = new LinkedList<>();
        for (final Integer value : inputs) {
            if (filterStrategy.acceptValue(value))
                result.add(value);
        }

        return result;
    }

    public static void main(final String[] args) {
        final List<Integer> inputs = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17);

        // EvenFilter und OddFilter (InverseEvenFilter)  
        final FilterStrategy evenFilter = new EvenFilter();
        System.out.println(evenFilter + ": " + filterAll(inputs, evenFilter));

        final FilterStrategy oddFilter = new InverseFilter(evenFilter);
        System.out.println(oddFilter + ": " + filterAll(inputs, oddFilter));


        var filter = new Not(new ClosedInterval(7, 13));
        System.out.println(filter + ": " + filterAll(inputs, filter));


        var special = new And(new ClosedInterval(4, 14), new Not(new IsPrime()));
        System.out.println(filter + ": " + filterAll(inputs, special));


        // PrimeFilter und InversePrimeFilter 
        final FilterStrategy isPrime = new IsPrime();
        System.out.println(isPrime + ": " + filterAll(inputs, isPrime));

        final FilterStrategy isNotPrime = new Not(isPrime);
        System.out.println(isNotPrime + ": " + filterAll(inputs, isNotPrime));


    }
}

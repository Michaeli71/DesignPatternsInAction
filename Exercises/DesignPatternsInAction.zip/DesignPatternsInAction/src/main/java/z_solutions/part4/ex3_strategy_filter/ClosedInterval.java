package z_solutions.part4.ex3_strategy_filter;

import part4.entwurfsmuster.behavioral.strategy.FilterStrategy;

/** Mathematisch: [lower,upper] --> lower <= value <= upper */
public class ClosedInterval implements FilterStrategy
{
    private final int lowerBound;
    private final int upperBound;

    public ClosedInterval(final int lowerBound, final int upperBound)
    {
    	if (upperBound < lowerBound)
    		throw new IllegalArgumentException("lowerBound must be <= upperBound");
    	
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
    }

    @Override
    public boolean acceptValue(final int value)
    {
        return lowerBound <= value && value <= upperBound;
    }

    @Override
    public String toString()
    {
        return "ClosedInterval [" + lowerBound + ", " + upperBound + "]";
    }
}
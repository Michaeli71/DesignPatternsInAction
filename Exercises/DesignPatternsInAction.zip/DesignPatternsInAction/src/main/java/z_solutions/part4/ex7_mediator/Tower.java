package z_solutions.part4.ex7_mediator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Tower {
    private final String name;

    private final List<Aircraft> aircrafts = new CopyOnWriteArrayList<>();

    public Tower(String name) {
        this.name = name;

    }

    public void registerAircraft(Aircraft aircraft) {
        aircrafts.add(aircraft);
    }

    public void deregisterAircraft(Aircraft aircraft) {
        aircrafts.remove(aircraft);
    }

    public void notifyAircrafts(String msg) {
        notifyAircrafts(msg, aircrafts);
    }

    private void notifyAircrafts(String msg, List<Aircraft> aircrafts) {
        for (Aircraft aircraft : aircrafts) {
            aircraft.receiveNotification(msg);
        }
    }

    public void receiveAircraftMsg(String msg, Aircraft sender) {
        List<Aircraft> aircraftsWithoutSender = new ArrayList<>(aircrafts);
        aircraftsWithoutSender.remove(sender);

        notifyAircrafts(sender.getName() + " reports " + msg, aircraftsWithoutSender);
    }
}

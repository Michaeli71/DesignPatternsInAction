package z_solutions.part4.ex3_strategy_filter;

import part4.entwurfsmuster.behavioral.strategy.FilterStrategy;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */

/** Filter auf gerade Zahlen */
public class EvenFilter implements FilterStrategy {
    @Override
    public boolean acceptValue(final int value) {
        return value % 2 == 0;
    }

    @Override
    public String toString() {
        return "EvenFilter";
    }
}
package z_solutions.part4.ex1_iterator;

import java.util.Iterator;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class EveryNthMultiListIterator<E> implements Iterator<E>
{
    private int           currentPos           = 0;

    private int           step;

    private final List<E> original;

    private int           elementsVisitedCount = 0;

    private int           offset               = 0;

    EveryNthMultiListIterator(List<E> original, int step)
    {
        this.original = original;
        this.step = step;
    }

    @Override
    public boolean hasNext()
    {
        return elementsVisitedCount < original.size();
    }

    @Override
    public E next()
    {
        // check at the end 
        if (currentPos >= original.size())
        {
            offset += 1;
            currentPos = offset;
        }

        E currentElement = original.get(currentPos);

        currentPos += step;
        elementsVisitedCount += 1;

        return currentElement;
    }

    public static void main(String[] args)
    {
        List<Integer> values = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);

        performIteration(values, 3);
        System.out.println("------------------");
        performIteration(values, 5);

        List<String> lines = List.of("Line1", "Tim", "Line2", "Tom", "Line3", "Mike");
        Iterator<String> it = new EveryNthMultiListIterator<>(lines, 2);
        while (it.hasNext())
        {
            System.out.println(it.next());
        }
    }

    private static void performIteration(List<Integer> values, int step)
    {
        Iterator<Integer> it = new EveryNthMultiListIterator<>(values, step);
        while (it.hasNext())
        {
            System.out.println(it.next());
        }
    }
}

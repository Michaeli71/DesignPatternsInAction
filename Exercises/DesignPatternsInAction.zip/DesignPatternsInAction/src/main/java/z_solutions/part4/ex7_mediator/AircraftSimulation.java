package z_solutions.part4.ex7_mediator;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class AircraftSimulation
{
    public static void main(String[] args)
    {
        Tower towerNY = new Tower("New York");
        Tower towerPH = new Tower("Philadelphia");

        Aircraft flight1 = Aircraft.create("Airbus A380", towerNY);
        Aircraft flight2 = Aircraft.create("Boeing 737", towerNY);
        Aircraft flight3 = Aircraft.create("FC04", towerPH);
        Aircraft flight4 = Aircraft.create("Boeing 747", towerNY);

        // 
        towerNY.notifyAircrafts("Stormy weather, danger of blizzards");
        towerPH.notifyAircrafts("change altitude + 1000");

        flight2.notifyTower("Mayday");

        // add on
        Tower towerW = new Tower("Washington");
        // Variante 1
        towerNY.deregisterAircraft(flight1);
        towerW.registerAircraft(flight1);
        towerW.notifyAircrafts("Warning: heavy rain");

        // ACHTUNG: verzahnte Aufrufe, register/deregister => noch komplizierter mit Multihtreading
        /*
        towerW.registerAircraft(flight1);
        towerNY.notifyAircrafts("Reminder: Stormy weather, danger of blizzards");
        towerNY.deregisterAircraft(flight1);
        towerW.notifyAircrafts("Warning: heavy rain");
        */

        flight2.notifyTower("Mayday, mayday! we are loosing control");
    }
}

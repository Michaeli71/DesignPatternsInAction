package z_solutions.part4.ex1_iterator;

import java.util.Iterator;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class EveryNthWithOffsetListIterator<E> implements Iterator<E> {
    private int currentPos = 0;

    private int step;

    private final List<E> original;

    EveryNthWithOffsetListIterator(List<E> original, int step, int startOffset) {
        this.original = original;
        this.step = step;
        this.currentPos = startOffset;
    }

    @Override
    public boolean hasNext() {
        return currentPos < original.size();
    }

    @Override
    public E next() {
        E currentElement = original.get(currentPos);

        currentPos += step;

        return currentElement;
    }

    public static void main(String[] args) {
        List<Integer> values = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);

        performIteration(values, 3);
        System.out.println("------------------");
        performIteration(values, 5);

        List<String> lines = List.of("BLA", "COMMENT", "xyz", "Line1", "Tim", "Line2", "Tom", "Line3", "Mike");
        Iterator<String> it = new EveryNthWithOffsetListIterator<>(lines, 2, 4);
        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }

    private static void performIteration(List<Integer> values, int step) {
        Iterator<Integer> it = new EveryNthWithOffsetListIterator<>(values, step, 0);
        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }
}

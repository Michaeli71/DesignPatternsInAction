package z_solutions.part4.ex1_iterator;

import java.util.Iterator;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class EvenPosListIterator<E> implements Iterator<E> {
    private int currentPos = 0;

    private final List<E> original;

    EvenPosListIterator(List<E> original) {
        this.original = original;
    }

    @Override
    public boolean hasNext() {
        return currentPos < original.size();
    }

    @Override
    public E next() {
        E currentElement = original.get(currentPos);

        currentPos += 2;

        return currentElement;
    }

    public static void main(String[] args) {
        List<Integer> values = List.of(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
        Iterator<Integer> it = new EvenPosListIterator<>(values);
        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }
}

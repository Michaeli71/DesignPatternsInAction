package z_solutions.part4.ex1_iterator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class RandomListIteratorV1<E> implements Iterator<E> {
    private int currentPos = 0;

    private List<E> shuffledList = List.of();

    RandomListIteratorV1(List<E> original) {
        this.shuffledList = new ArrayList<>(original);
        Collections.shuffle(shuffledList);
    }

    @Override
    public boolean hasNext() {
        return currentPos < shuffledList.size();
    }

    @Override
    public E next() {
        E currentElement = shuffledList.get(currentPos);

        currentPos++;

        return currentElement;
    }

    public static void main(String[] args) {

        List<Integer> values = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        Iterator<Integer> it = new RandomListIteratorV1<>(values);
        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }
}

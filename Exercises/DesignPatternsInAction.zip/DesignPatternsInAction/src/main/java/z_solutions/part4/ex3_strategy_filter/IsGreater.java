package z_solutions.part4.ex3_strategy_filter;

import part4.entwurfsmuster.behavioral.strategy.FilterStrategy;

/**
 * Utility-Klasse zur Filterung mithilfe des Strategie-Musters
 * <br>
 * Die Klasse <code>InverseFilter</code> erlaubt es beliebige Filterkriterien zu
 * invertieren. Sie ist gem�� dem Dekorierer-Muster realisiert.
 *
 * @author Michael Inden
 * <p>
 * Copyright 2011 by Michael Inden
 */
public final class IsGreater implements FilterStrategy {
    final int baseValue;

    public IsGreater(int baseValue) {
        this.baseValue = baseValue;
    }


    @Override
    public boolean acceptValue(final int value) {
        return value > baseValue;
    }

    @Override
    public String toString() {
        return "IsGreater " + baseValue;
    }
}
package z_solutions.part5.ex1_strategy_filter;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Beispielprogramm zur Filterung mithilfe des Strategie-Musters
 * <br>
 * Die Klasse <code>StrategyFilterExample</code> zeigt eine Filterung
 * von einer Liste von Integer-Werten und zwei Filter-Kriterien
 * (offenes und geschlossenes Intervall).
 * Als Erweiterung zum einf�hrenden Beispiel  <code>StrategyFilterBaseExample</code>
 * wird die Filterung hier nicht in der Methode <code>filterAll()</code> ausprogrammiert,
 * sondern stattdessen an eine <code>FilterStrategy</code> delegiert. Dieses Interface
 * wird hier von den beiden Realisierungen <code>ClosedInterval</code> und <code>OpenInterval</code>
 * erf��llt.
 *
 * @author Michael Inden
 * <p>
 * Copyright 2014 by Michael Inden
 */
public final class StrategyFilterExampleJdk8_Step3 {
    // Step 1: Anpassung auf Streams und Predicate
    // Step 2: Umstellung auf Predicate<Integer>
    public static List<Integer> filterAll(final List<Integer> inputs,
                                          final Predicate<Integer> filterStrategy) {
        return inputs.stream().
                filter(filterStrategy).
                collect(Collectors.toList());
    }

    // Step 3: Eigenständige Lmabdas definieren
    public static void main(final String[] args) {
        final List<Integer> inputs = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);

        System.out.println("Filtering values for Intervall 2-7");
        final Predicate<Integer> closedInterval = FilterStrategies_Jdk8.closedInterval(2, 7);
        System.out.println("Using " + closedInterval + " " + filterAll(inputs, closedInterval));

        final Predicate<Integer> openInterval = FilterStrategies_Jdk8.openInterval(2, 7);
        System.out.println("Using " + openInterval + " " + filterAll(inputs, openInterval));

        final Predicate<Integer> openInterval2 = FilterStrategies_Jdk8.openInterval(2, 6);
        final Predicate<Integer> isOdd = n -> n % 2 != 0;
        final Predicate<Integer> combined = isOdd.or(openInterval2);
        System.out.println("Using " + openInterval + " " + filterAll(inputs, combined));


    }
}

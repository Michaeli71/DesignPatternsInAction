package z_solutions.part5.ex4_strategy_validation;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class IsAllLowerCase implements ValidationStrategy
{
    @Override
    public boolean validate(String input)
    {
        return input.matches("[a-z]+");
    }
}

package z_solutions.part5.ex2_execute_around;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Consumer;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ExecuteAroundPatternExample
{
    public static void main(String[] args)
    {
        Lock lock = new ReentrantReadWriteLock().readLock();
        withLock(lock, acquiredLock -> {
            System.out.println("Ich bin geschützt");
        });

    }

    // Übungsaufgabe
    public static void withLock(final Lock lock, final Consumer<Lock> block)
    {
        lock.lock();
        try
        {
            block.accept(lock);
        }
        finally
        {
            lock.unlock();
        }
    }
}

package z_solutions.part2.ex2.step1;

import z_solutions.part2.ex2.GameEntity;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class GameCharacterGenerator
{
    public static void main(String[] args)
    {
        GameEntity ufo = createGameEntity("UFO");
        GameEntity bullet = createGameEntity("BULLET");
        GameEntity player = createGameEntity("PLAYER");
    }

    // Abstraktion vom konkreten Typ
    public static GameEntity createGameEntity(final String type)
    {
        if (type.equalsIgnoreCase("UFO"))
            return new Ufo();
        if (type.equalsIgnoreCase("BULLET"))
            return new Bullet();
        if (type.equalsIgnoreCase("PLAYER"))
            return new Ufo();

        throw new IllegalStateException("undefined type");
    }

    static class Ufo extends GameEntity
    {

    }

    static class Bullet extends GameEntity
    {

    }

    static class Player extends GameEntity
    {

    }

}

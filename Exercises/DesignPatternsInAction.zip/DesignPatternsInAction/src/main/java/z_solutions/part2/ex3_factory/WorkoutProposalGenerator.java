package z_solutions.part2.ex3_factory;

import z_exercises.part2.ex3_factory.Workout;
import z_exercises.part2.ex3_factory.WorkoutType;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class WorkoutProposalGenerator
{
    public static void main(String[] args)
    {
        // Potenzielle Erweiterung: Zufällige Auswahl aus den enum-Workouts
        Workout workout = WorkoutFactory.getWorkout(WorkoutType.UPPERBODY);
        workout.createWorkout();

        workout = WorkoutFactory.getWorkout(WorkoutType.LOWERBODY);
        workout.createWorkout();

        workout = WorkoutFactory.getWorkout(WorkoutType.ENDURANCE);
        workout.createWorkout();
    }
}
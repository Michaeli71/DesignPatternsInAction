package z_solutions.part2.ex3_factory;

import z_exercises.part2.ex3_factory.Endurance;
import z_exercises.part2.ex3_factory.LowerBody;
import z_exercises.part2.ex3_factory.UpperBody;
import z_exercises.part2.ex3_factory.Workout;
import z_exercises.part2.ex3_factory.WorkoutType;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class WorkoutFactory
{
    public static Workout getWorkout(WorkoutType workoutType)
    {
        switch (workoutType)
        {
            case UPPERBODY:
            {
                return new UpperBody();
            }
            case LOWERBODY:
            {
                return new LowerBody();
            }
            case ENDURANCE:
            {
                return new Endurance();
            }
            default:
            {
                throw new IllegalStateException("unsupported workout type");
            }
        }
    }
}
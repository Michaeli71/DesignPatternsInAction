package z_solutions.part2.ex2.step2;

import z_solutions.part2.ex2.GameEntity;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class GameCharacterGeneratorWithFactory {
    public static void main(String[] args) {
        GameEntity ufo = GameCharacterFactory.createGameEntity("UFO");
        GameEntity bullet = GameCharacterFactory.createGameEntity("BULLET");
        GameEntity player = GameCharacterFactory.createGameEntity("PLAYER");
    }
}

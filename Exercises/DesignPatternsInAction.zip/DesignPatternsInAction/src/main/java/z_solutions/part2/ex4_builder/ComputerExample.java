package z_solutions.part2.ex4_builder;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class ComputerExample {
    public static void main(String[] args) {
        Computer iMac2020 = new Computer.ComputerBuilder(
                "2 TB", "72 GB").setBluetoothEnabled(true)
                .setGraphicsCardEnabled(true).build();

        // schönere Variante mit sprechenden Methodennamen
        Computer oldCompi = new Computer.ComputerBuilder(
                "500 GB", "2 GB").
                noBluetooth().
                withGraphicsCardEnabled().
                build();

        System.out.println(iMac2020);
        System.out.println(oldCompi);
    }
}

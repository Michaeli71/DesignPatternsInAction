package z_solutions.part2.ex4_builder;

import java.util.Objects;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class BankAccount {

    private final long accountNumber;
    private final String owner;
    private final String branch;
    private double balance;
    private double interestRate;

    public static class Builder {

        private final long accountNumber;
        private final String owner;
        private String branch = ""; // Optional field
        private double balance = 0.0;
        private double interestRate = 0.0;

        public Builder(long accountNumber, String owner) {
            // sanity check of required attributes
            if (accountNumber < 0)
                throw new IllegalArgumentException("account number must be positive");
            Objects.requireNonNull(owner, "account number is mandatory");

            this.accountNumber = accountNumber;
            this.owner = owner;
        }

        public Builder atBranch(String branch) {
            this.branch = branch;
            return this;
        }

        public Builder noBranch() {
            this.branch = "";
            return this;
        }

        public Builder withBalance(double balance) {
            this.balance = balance;
            return this;
        }

        public Builder atRate(double interestRate) {
            this.interestRate = interestRate;
            return this;
        }

        public BankAccount build() {
            // ALternativ hier, aber dann bereits eigentlich zu spät, gemäß fail fast
            // sanity check of required attributes
            if (accountNumber < 0)
                throw new IllegalArgumentException("account number must be positive");
            Objects.requireNonNull(owner, "account number is mandatory");

            return new BankAccount(accountNumber, owner, branch, balance, interestRate);
        }
    }

    /*private*/ BankAccount(long accountNumber, String owner, String branch, double balance, double interestRate) {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.branch = branch;
        this.balance = balance;
        this.interestRate = interestRate;
    }

    @Override
    public String toString() {
        return "BankAccount [accountNumber=" + accountNumber + ", owner=" + owner + ", branch=" + branch + ", balance="
                + balance + ", interestRate=" + interestRate + "]";
    }
}

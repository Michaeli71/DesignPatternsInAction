package z_solutions.part2.ex1;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class PizzaCreator {
    public static void main(String[] args) {
        orderPizza("Napoli");
        orderPizza("Funghi");
    }

    // Objektcreation auslagern => Erzeugungsmethode
    static Pizza orderPizza(String type) {
        if (type.equalsIgnoreCase("Napoli"))
            return new PizzaNapoli();
        if (type.equalsIgnoreCase("Funghi"))
            return new PizzaFunghi();
        if (type.equalsIgnoreCase("Surprise"))
            return new PizzaSurprise();

        // Probelmatisch bzgl. OPEN CLOSED PRINCIPLE
        // Margherita
        // Peperoni
        // ...

        throw new IllegalStateException("unsupported type");
    }

    static interface Pizza {
    }

    static class PizzaNapoli implements Pizza {

    }

    static class PizzaFunghi implements Pizza {

    }

    static class PizzaSurprise implements Pizza {

    }
}

package z_solutions.part2.ex2.step2;

import z_solutions.part2.ex2.GameEntity;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class GameCharacterFactory {
    // Abstraktion vom konkreten Typ
    public static GameEntity createGameEntity(final String type) {
        if (type.equalsIgnoreCase("UFO"))
            return new Ufo();
        if (type.equalsIgnoreCase("BULLET"))
            return new Bullet();
        if (type.equalsIgnoreCase("PLAYER"))
            return new Ufo();

        throw new IllegalStateException("undefined type");
    }

    static class Ufo extends GameEntity {

    }

    static class Bullet extends GameEntity {

    }

    static class Player extends GameEntity {

    }
}

package part5.patterns.chain;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public abstract class Processor<T> {
    private Processor<T> successor;

    public void setSuccessor(Processor<T> successor) {
        this.successor = successor;
    }

    public T handle(T input) {
        T r = process(input);
        if (successor != null) {
            return successor.handle(r);
        }
        return r;
    }

    abstract protected T process(T input);
}
package part5.patterns.strategy.modernized;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class StrategyModernizedExample
{
    public static void main(String[] args)
    {
        List<String> names1 = List.of("Tim", "Tom", "Peter", "Mike", "Michael");
        Stream<String> names2 = Stream.of("Tim", "Tom", "Peter", "Mike", "Michael");
        Stream<String> names3 = Stream.of("Tim", "Tom", "Peter", "Mike", "Michael");

        // Strategy by Definition Predicates
        Predicate<String> startsWithT = str -> str.startsWith("T");
        Predicate<String> moreThan4Chars = str -> str.length() > 4;
        Predicate<String> moreThan6Chars = longerThan(6);

        names1.stream().filter(startsWithT).forEach(System.out::println);
        names2.filter(moreThan4Chars).forEach(System.out::println);
        names3.filter(moreThan6Chars).forEach(System.out::println);
    }

    // Trick dynamische Parametrierung
    static Predicate<String> longerThan(int lowerBound)
    {
        return str -> str.length() > lowerBound;
    }
}

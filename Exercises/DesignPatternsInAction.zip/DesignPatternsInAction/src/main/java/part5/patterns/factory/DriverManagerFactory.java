package part5.patterns.factory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class DriverManagerFactory
{
    static class WebDriver
    {
    }

    static class ChromeDriver extends WebDriver
    {
    }

    static class FirefoxDriver extends WebDriver
    {
    }
    
    // Problems: not easily extensible
    public static WebDriver getDriver(DriverType type)
    {
        WebDriver driver;
    
        switch (type)
        {
            case CHROME:
                System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
                driver = new ChromeDriver();
                break;
            case FIREFOX:
                System.setProperty("webdriver.gecko.driver", "/Users/username/Downloads/geckodriver");
                driver = new FirefoxDriver();
                break;
            default:
                throw new IllegalArgumentException("Unsupported driver type");
        }
        return driver;
    }
}
package part5.patterns.execute_around;

import java.io.IOException;
import java.util.function.Consumer;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class ExecuteAroundPatternExample {
    // Analog zu Autocloseable
    static class Resource {
        public Resource() {
            System.out.println("created");
        }

        public void op1() throws IOException {
            System.out.println("op1");
        }

        public void op2() {
            System.out.println("op2");
        }

        public void close() {
            System.out.println("close");
        }
    }

    public static void main(String[] args) {
        Resource rs = new Resource();
        try {
            rs.op1();
            rs.op2();
            // rs.close();
        } catch (IOException ioe) {
            handleIoException(ioe);
        } finally {
            // rs.close();
        }

        Resource rs2 = new Resource();
        withClose(rs2, res -> {
            try {
                res.op1();
                res.op2();
            } catch (IOException ioe) {
                handleIoException(ioe);
            }
        });
    }

    private static void handleIoException(IOException ioe) {
    }

    public static void withClose(final Resource resource, final Consumer<Resource> block) {
        try {
            block.accept(resource);
        } finally {
            resource.close();
        }
    }
}

package part5.patterns.factory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public enum DriverType {
    CHROME,
    FIREFOX,
    SAFARI,
    IE;
}
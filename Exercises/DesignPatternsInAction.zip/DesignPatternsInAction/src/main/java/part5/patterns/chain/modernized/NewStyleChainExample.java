package part5.patterns.chain.modernized;

import java.util.function.Function;
import java.util.function.UnaryOperator;

import part5.patterns.chain.InfoAdder;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class NewStyleChainExample {
	public static void main(String[] args) {

		//UnaryOperator<String> headerProcessing = (String text) -> "Hey workshop partiipants: " + text;
		UnaryOperator<String> headerProcessing = (String text) -> new InfoAdder().process(text);

		UnaryOperator<String> spellCheckerProcessing = (String text) -> text.replaceAll("labda", "lambda");
		
		UnaryOperator<String> converterProcessing = (String text) -> text.replaceAll("beautiful", "cool");

		Function<String, String> pipeline = headerProcessing.andThen(spellCheckerProcessing).andThen(converterProcessing);
		
		String result = pipeline.apply("labdas are really beautiful!");
		System.out.println(result);
	}
}

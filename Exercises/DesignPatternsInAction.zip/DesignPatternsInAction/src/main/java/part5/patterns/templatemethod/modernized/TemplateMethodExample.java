package part5.patterns.templatemethod.modernized;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class TemplateMethodExample {
    public final void templateMethod(Runnable first, Runnable last) {
        first.run();
        step1();
        step2();
        step3();
        hook();
        last.run();
    }

    void step1() {
        System.out.println("step1");
    }

    void step2() {
        System.out.println("step2");
    }

    void step3() {
        System.out.println("step3");
    }

    protected void hook() {
    }

    public static void main(String[] args) {
        TemplateMethodExample tme = new TemplateMethodExample();
        tme.templateMethod(() -> System.out.println("FIRST"),
                () -> System.out.println("LAST"));
    }
}

package part5.patterns.chain;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class SpellChecker extends Processor<String> {
    @Override
    public String process(String text) {
        return text.replaceAll("labda", "lambda");
    }
}